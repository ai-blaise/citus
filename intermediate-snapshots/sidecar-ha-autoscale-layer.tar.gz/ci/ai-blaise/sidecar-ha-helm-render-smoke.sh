#!/usr/bin/env bash
set -euo pipefail

# FEATURE: SC1
# FEATURE: SC2
# FEATURE: SC3
# FEATURE: SC4
# FEATURE: SC5
# FEATURE: SC6
#
# Render the citus-overlay Helm chart under values.yaml, values-prod.yaml,
# and values-exhaustive.yaml and prove every sidecar HA layer artifact is
# emitted as expected for the production HA contract:
#
#   - Deployment carries topologySpreadConstraints, podAntiAffinity,
#     terminationGracePeriodSeconds, priorityClassName, startupProbe,
#     readinessProbe, and livenessProbe wired to /healthz + /readyz.
#   - Each enabled sidecar gets a Service, PodDisruptionBudget,
#     ServiceMonitor, and NetworkPolicy.
#   - Consensus sidecars (raft, hlc, txn-status) get the critical
#     PriorityClass, minAvailable PDB, and NO HorizontalPodAutoscaler.
#   - Traffic-bound sidecars (analytical, vectorizer, cdc, realtime,
#     postgrest, graphql, edge-functions, mcp, storage, auth) get an
#     HorizontalPodAutoscaler with CPU + memory targets.
#   - Default (values.yaml) and production (values-prod.yaml) renders do
#     not include any sidecar artifacts because every alpha sidecar is
#     disabled by default; only the PriorityClass cluster-scope objects
#     are emitted so cluster operators can reference them ahead of time.
#
# The smoke is exit-non-zero on any missing artifact and is designed to run
# without a live cluster: it only renders the chart via `helm template`.

repo_root="$(git rev-parse --show-toplevel)"
cd "${repo_root}"

chart_dir="deploy/k8s/helm/citus-overlay"
release="sidecar-ha-smoke"

if ! command -v helm >/dev/null 2>&1; then
  echo "helm is required for the sidecar HA render smoke" >&2
  exit 1
fi

render_dir="$(mktemp -d)"
trap 'rm -rf "${render_dir}"' EXIT

required_sidecars=(
  analytical auth backup cdc coldtier edge-functions graphql hlc mcp
  postgrest raft realtime repack schema-job storage txn-status vectorizer
)

hpa_sidecars=(
  analytical auth cdc edge-functions graphql mcp postgrest realtime storage
  vectorizer
)

consensus_sidecars=(raft hlc txn-status)

assert_kind_for_each_sidecar() {
  local file="$1"
  local kind="$2"
  local label="$3"
  local sidecar
  for sidecar in "${required_sidecars[@]}"; do
    python3 - "${file}" "${kind}" "ai-blaise-citus-sidecar-${sidecar}" "${label}" <<'PY'
import pathlib
import sys

text = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
target_kind = sys.argv[2]
target_name = sys.argv[3]
label = sys.argv[4]

found = False
for chunk in text.split("\n---\n"):
    lines = chunk.splitlines()
    kinds = [line for line in lines if line.startswith("kind:")]
    names = [line for line in lines if line.startswith("  name: ")]
    if not kinds or not names:
        continue
    if kinds[0].strip() == f"kind: {target_kind}" and names[0].strip() == f"name: {target_name}":
        found = True
        break

if not found:
    print(f"{label}: missing {target_kind} for {target_name}", file=sys.stderr)
    sys.exit(1)
PY
  done
}

assert_no_kind_for_sidecars() {
  local file="$1"
  local kind="$2"
  local label="$3"
  shift 3
  local sidecar
  for sidecar in "$@"; do
    python3 - "${file}" "${kind}" "ai-blaise-citus-sidecar-${sidecar}" "${label}" <<'PY'
import pathlib
import sys

text = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
target_kind = sys.argv[2]
target_name = sys.argv[3]
label = sys.argv[4]

for chunk in text.split("\n---\n"):
    lines = chunk.splitlines()
    kinds = [line for line in lines if line.startswith("kind:")]
    names = [line for line in lines if line.startswith("  name: ")]
    if not kinds or not names:
        continue
    if kinds[0].strip() == f"kind: {target_kind}" and names[0].strip() == f"name: {target_name}":
        print(f"{label}: {target_kind} unexpectedly rendered for {target_name}", file=sys.stderr)
        sys.exit(1)
PY
  done
}

assert_priorityclasses() {
  local file="$1"
  local label="$2"
  if ! grep -q 'name: citus-sidecar-critical' "${file}"; then
    echo "${label}: PriorityClass citus-sidecar-critical missing" >&2
    return 1
  fi
  if ! grep -q 'name: citus-sidecar-default' "${file}"; then
    echo "${label}: PriorityClass citus-sidecar-default missing" >&2
    return 1
  fi
}

assert_deployment_ha_fields() {
  local file="$1"
  local label="$2"
  local marker
  for marker in \
    'topologySpreadConstraints:' \
    'topologyKey: topology.kubernetes.io/zone' \
    'podAntiAffinity:' \
    'terminationGracePeriodSeconds:' \
    'priorityClassName: citus-sidecar-critical' \
    'priorityClassName: citus-sidecar-default' \
    'startupProbe:' \
    'readinessProbe:' \
    'livenessProbe:' \
    'path: /readyz' \
    'path: /healthz'; do
    if ! grep -q "${marker}" "${file}"; then
      echo "${label}: required marker '${marker}' missing" >&2
      return 1
    fi
  done
}

assert_consensus_pdbs() {
  local file="$1"
  local label="$2"
  local sidecar
  for sidecar in "${consensus_sidecars[@]}"; do
    python3 - "${file}" "${sidecar}" "${label}" <<'PY'
import pathlib
import sys

text = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
sidecar = sys.argv[2]
label = sys.argv[3]
target = f"ai-blaise-citus-sidecar-{sidecar}"

for chunk in text.split("\n---\n"):
    lines = chunk.splitlines()
    kinds = [line for line in lines if line.startswith("kind:")]
    names = [line for line in lines if line.startswith("  name: ")]
    if not kinds or not names:
        continue
    if kinds[0].strip() == "kind: PodDisruptionBudget" and names[0].strip() == f"name: {target}":
        if any(line.lstrip().startswith("minAvailable:") for line in lines):
            sys.exit(0)
        print(f"{label}: consensus PDB for {sidecar} missing minAvailable", file=sys.stderr)
        sys.exit(1)

print(f"{label}: consensus PDB for {sidecar} missing", file=sys.stderr)
sys.exit(1)
PY
  done
}

assert_traffic_bound_hpas() {
  local file="$1"
  local label="$2"
  local sidecar
  for sidecar in "${hpa_sidecars[@]}"; do
    python3 - "${file}" "${sidecar}" "${label}" <<'PY'
import pathlib
import sys

text = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
sidecar = sys.argv[2]
label = sys.argv[3]
target = f"ai-blaise-citus-sidecar-{sidecar}"

for chunk in text.split("\n---\n"):
    lines = chunk.splitlines()
    kinds = [line for line in lines if line.startswith("kind:")]
    names = [line for line in lines if line.startswith("  name: ")]
    if not kinds or not names:
        continue
    if kinds[0].strip() == "kind: HorizontalPodAutoscaler" and names[0].strip() == f"name: {target}":
        sys.exit(0)

print(f"{label}: traffic-bound HPA missing for sidecar {sidecar}", file=sys.stderr)
sys.exit(1)
PY
  done
}

assert_hpa_targets() {
  local file="$1"
  local label="$2"
  if ! grep -q 'averageUtilization: 70' "${file}"; then
    echo "${label}: HPA cpu target 70 missing" >&2
    return 1
  fi
  if ! grep -q 'averageUtilization: 80' "${file}"; then
    echo "${label}: HPA memory target 80 missing" >&2
    return 1
  fi
  if ! grep -q 'maxReplicas: 10' "${file}"; then
    echo "${label}: HPA maxReplicas 10 missing" >&2
    return 1
  fi
}

assert_networkpolicy_tiers() {
  local file="$1"
  local label="$2"
  local tier
  for tier in api db consensus; do
    if ! grep -q "ai-blaise.com/network-tier: ${tier}" "${file}"; then
      echo "${label}: NetworkPolicy ${tier} tier missing" >&2
      return 1
    fi
  done
}

assert_prometheusrule_alerts() {
  local file="$1"
  local label="$2"
  local alert
  for alert in \
    AiBlaiseCitusSidecarBelowDesiredReplicas \
    AiBlaiseCitusSidecarErrorRateHigh \
    AiBlaiseCitusSidecarLatencyP99High; do
    if ! grep -q "alert: ${alert}" "${file}"; then
      echo "${label}: alert ${alert} missing" >&2
      return 1
    fi
  done
}

assert_no_sidecar_objects() {
  local file="$1"
  local label="$2"
  local pattern="name: ai-blaise-citus-sidecar-"
  if grep -q "${pattern}" "${file}"; then
    echo "${label}: sidecar objects unexpectedly rendered (alpha must remain disabled)" >&2
    grep "${pattern}" "${file}" >&2
    return 1
  fi
}

# 1. Exhaustive profile: every sidecar enabled. All HA artifacts present.
helm template "${release}" "${chart_dir}" \
  -f "${chart_dir}/values-exhaustive.yaml" >"${render_dir}/exhaustive.yaml"

assert_priorityclasses "${render_dir}/exhaustive.yaml" "exhaustive"
assert_kind_for_each_sidecar "${render_dir}/exhaustive.yaml" "Deployment" "exhaustive"
assert_kind_for_each_sidecar "${render_dir}/exhaustive.yaml" "Service" "exhaustive"
assert_kind_for_each_sidecar "${render_dir}/exhaustive.yaml" "PodDisruptionBudget" "exhaustive"
assert_kind_for_each_sidecar "${render_dir}/exhaustive.yaml" "ServiceMonitor" "exhaustive"
assert_kind_for_each_sidecar "${render_dir}/exhaustive.yaml" "NetworkPolicy" "exhaustive"
assert_deployment_ha_fields "${render_dir}/exhaustive.yaml" "exhaustive"
assert_consensus_pdbs "${render_dir}/exhaustive.yaml" "exhaustive"
assert_traffic_bound_hpas "${render_dir}/exhaustive.yaml" "exhaustive"
assert_hpa_targets "${render_dir}/exhaustive.yaml" "exhaustive"
assert_no_kind_for_sidecars "${render_dir}/exhaustive.yaml" "HorizontalPodAutoscaler" \
  "exhaustive" "${consensus_sidecars[@]}"
assert_networkpolicy_tiers "${render_dir}/exhaustive.yaml" "exhaustive"
assert_prometheusrule_alerts "${render_dir}/exhaustive.yaml" "exhaustive"

# 2. Default values.yaml: no sidecar artifacts (alpha sidecars all disabled),
# but the PriorityClass objects must render so consumers can pre-create them.
helm template "${release}" "${chart_dir}" \
  --set operator.image.digest=sha256:1111111111111111111111111111111111111111111111111111111111111111 \
  --set pool.image.digest=sha256:2222222222222222222222222222222222222222222222222222222222222222 \
  >"${render_dir}/default.yaml"

assert_priorityclasses "${render_dir}/default.yaml" "default"
assert_no_sidecar_objects "${render_dir}/default.yaml" "default"

# 3. Production values: same expectations as default (sidecars disabled).
helm template "${release}" "${chart_dir}" \
  -f "${chart_dir}/values-prod.yaml" \
  --set operator.image.digest=sha256:1111111111111111111111111111111111111111111111111111111111111111 \
  --set pool.image.digest=sha256:2222222222222222222222222222222222222222222222222222222222222222 \
  >"${render_dir}/prod.yaml"

assert_priorityclasses "${render_dir}/prod.yaml" "prod"
assert_no_sidecar_objects "${render_dir}/prod.yaml" "prod"

# 4. Confirm production replica floor is at least 2 (and 3 for consensus)
# for every sidecar entry in values-prod.yaml.
python3 - "${chart_dir}/values-prod.yaml" <<'PY'
import pathlib
import re
import sys

text = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
consensus = {"raft", "hlc", "txn-status"}
findings = []
pattern = re.compile(
    r"^\s*-\s+name:\s+(\S+)\s*\n(?:\s+\S.*\n)*?\s+replicas:\s+(\d+)",
    re.M,
)
for match in pattern.finditer(text):
    name = match.group(1)
    replicas = int(match.group(2))
    floor = 3 if name in consensus else 2
    if replicas < floor:
        findings.append(f"{name} has replicas={replicas} (need >= {floor})")

if findings:
    for finding in findings:
        print(finding, file=sys.stderr)
    sys.exit(1)
PY

echo "sidecar HA helm render smoke passed"
