//! Companion-side helpers for the realtime sidecar.
//!
//! Generates the SQL the operator runs to (a) register a realtime channel
//! against `companion_internal.realtime_channels`, (b) install a per-channel
//! RLS policy that scopes broadcasts to a tenant identifier, and (c) record
//! the bridge endpoint the realtime sidecar should pull CDC events from.

// FEATURE: RT1
// FEATURE: RT2
// FEATURE: RT3
// FEATURE: RT4
// FEATURE: RT5

use std::error::Error;
use std::fmt;

#[derive(Debug, Clone, Eq, PartialEq)]
pub struct RealtimeChannelPlan {
    pub channel_name: String,
    pub schema: String,
    pub table: String,
    pub tenant_column: String,
    pub events: Vec<RealtimeChannelEvent>,
    pub bridge_addr: String,
    pub rls_policy_name: String,
    pub rls_using_clause: String,
}

impl RealtimeChannelPlan {
    pub fn validate(&self) -> Result<(), RealtimeChannelError> {
        validate_identifier("channel_name", &self.channel_name)?;
        validate_identifier("schema", &self.schema)?;
        validate_identifier("table", &self.table)?;
        validate_identifier("tenant_column", &self.tenant_column)?;
        validate_required("bridge_addr", &self.bridge_addr)?;
        validate_identifier("rls_policy_name", &self.rls_policy_name)?;
        validate_required("rls_using_clause", &self.rls_using_clause)?;
        if self.events.is_empty() {
            return Err(RealtimeChannelError::MissingRequiredField("events"));
        }
        if !self.bridge_addr.contains(':') {
            return Err(RealtimeChannelError::InvalidBridgeAddr);
        }
        Ok(())
    }

    pub fn to_sql_plan(&self) -> Result<RealtimeSqlPlan, RealtimeChannelError> {
        self.validate()?;
        let events = self
            .events
            .iter()
            .map(|event| event.as_sql().to_string())
            .collect::<Vec<_>>();
        let table_qualified = format!("{}.{}", self.schema, self.table);
        Ok(RealtimeSqlPlan {
            feature_id: "RT1",
            statements: vec![
                format!(
                    "SELECT companion_internal.realtime_channel_register({}, {}, {}, {}, {}, {});",
                    sql_literal(&self.channel_name),
                    sql_literal(&self.schema),
                    sql_literal(&self.table),
                    sql_literal(&self.tenant_column),
                    array_literal(&events),
                    sql_literal(&self.bridge_addr),
                ),
                format!(
                    "ALTER TABLE {qualified} ENABLE ROW LEVEL SECURITY;",
                    qualified = quote_identifier(&self.schema)
                        + "."
                        + &quote_identifier(&self.table)
                ),
                format!(
                    "CREATE POLICY {policy} ON {qualified} FOR SELECT TO PUBLIC USING ({using_clause});",
                    policy = quote_identifier(&self.rls_policy_name),
                    qualified = quote_identifier(&self.schema)
                        + "."
                        + &quote_identifier(&self.table),
                    using_clause = self.rls_using_clause,
                ),
                format!(
                    "SELECT companion_internal.realtime_channel_bind_policy({}, {}, {});",
                    sql_literal(&self.channel_name),
                    sql_literal(&table_qualified),
                    sql_literal(&self.rls_policy_name),
                ),
            ],
        })
    }
}

#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum RealtimeChannelEvent {
    Insert,
    Update,
    Delete,
}

impl RealtimeChannelEvent {
    fn as_sql(self) -> &'static str {
        match self {
            Self::Insert => "INSERT",
            Self::Update => "UPDATE",
            Self::Delete => "DELETE",
        }
    }
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub struct RealtimeSqlPlan {
    pub feature_id: &'static str,
    pub statements: Vec<String>,
}

impl RealtimeSqlPlan {
    pub fn statements(&self) -> &[String] {
        &self.statements
    }
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub enum RealtimeChannelError {
    MissingRequiredField(&'static str),
    InvalidIdentifier(&'static str),
    InvalidBridgeAddr,
}

impl fmt::Display for RealtimeChannelError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::MissingRequiredField(field) => write!(formatter, "{field} must not be empty"),
            Self::InvalidIdentifier(field) => {
                write!(formatter, "{field} must be a non-empty SQL identifier")
            }
            Self::InvalidBridgeAddr => write!(formatter, "bridge_addr must be host:port"),
        }
    }
}

impl Error for RealtimeChannelError {}

fn validate_required(field: &'static str, value: &str) -> Result<(), RealtimeChannelError> {
    if value.trim().is_empty() {
        return Err(RealtimeChannelError::MissingRequiredField(field));
    }
    Ok(())
}

fn validate_identifier(field: &'static str, value: &str) -> Result<(), RealtimeChannelError> {
    validate_required(field, value)?;
    if value
        .chars()
        .all(|ch| ch.is_ascii_alphanumeric() || ch == '_')
    {
        Ok(())
    } else {
        Err(RealtimeChannelError::InvalidIdentifier(field))
    }
}

fn sql_literal(value: &str) -> String {
    let mut quoted = String::with_capacity(value.len() + 2);
    quoted.push('\'');
    for ch in value.chars() {
        if ch == '\'' {
            quoted.push('\'');
        }
        quoted.push(ch);
    }
    quoted.push('\'');
    quoted
}

fn array_literal(values: &[String]) -> String {
    let mut output = String::with_capacity(values.len() * 8 + 4);
    output.push_str("ARRAY[");
    for (index, value) in values.iter().enumerate() {
        if index > 0 {
            output.push_str(", ");
        }
        output.push_str(&sql_literal(value));
    }
    output.push(']');
    output
}

fn quote_identifier(value: &str) -> String {
    format!("\"{value}\"")
}

pub fn canonical_realtime_channel_plan() -> RealtimeChannelPlan {
    RealtimeChannelPlan {
        channel_name: "orders_paid".to_string(),
        schema: "public".to_string(),
        table: "orders".to_string(),
        tenant_column: "tenant_id".to_string(),
        events: vec![
            RealtimeChannelEvent::Insert,
            RealtimeChannelEvent::Update,
        ],
        bridge_addr: "ai-blaise-citus-sidecar-realtime:4001".to_string(),
        rls_policy_name: "orders_realtime_tenant_isolation".to_string(),
        rls_using_clause: "tenant_id = current_setting('app.tenant_id', true)".to_string(),
    }
}

pub fn canonical_realtime_sql_plan() -> Result<RealtimeSqlPlan, RealtimeChannelError> {
    canonical_realtime_channel_plan().to_sql_plan()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn channel_plan_generates_sql() {
        let plan = canonical_realtime_sql_plan().expect("plan");
        assert_eq!(plan.feature_id, "RT1");
        let statements = plan.statements();
        assert!(statements[0].starts_with(
            "SELECT companion_internal.realtime_channel_register('orders_paid', 'public', 'orders', 'tenant_id',"
        ));
        assert!(statements[1].contains("ENABLE ROW LEVEL SECURITY"));
        assert!(statements[2].contains("CREATE POLICY \"orders_realtime_tenant_isolation\""));
        assert!(statements[2].contains(
            "USING (tenant_id = current_setting('app.tenant_id', true))"
        ));
        assert!(statements[3].contains("realtime_channel_bind_policy"));
    }

    #[test]
    fn channel_plan_rejects_missing_events() {
        let mut plan = canonical_realtime_channel_plan();
        plan.events.clear();
        assert_eq!(
            plan.validate(),
            Err(RealtimeChannelError::MissingRequiredField("events"))
        );
    }

    #[test]
    fn channel_plan_rejects_bad_bridge() {
        let mut plan = canonical_realtime_channel_plan();
        plan.bridge_addr = "no-port".to_string();
        assert_eq!(plan.validate(), Err(RealtimeChannelError::InvalidBridgeAddr));
    }

    #[test]
    fn channel_plan_rejects_non_identifier_schema() {
        let mut plan = canonical_realtime_channel_plan();
        plan.schema = "public schema".to_string();
        assert_eq!(
            plan.validate(),
            Err(RealtimeChannelError::InvalidIdentifier("schema"))
        );
    }
}
