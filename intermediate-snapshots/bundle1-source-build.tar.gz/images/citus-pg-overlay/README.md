# citus-pg-overlay

> Production boundary: unless a feature is explicitly `Status: production-ready`
> in `docs/ai-blaise/NEW_FEATURES.md`, the surfaces listed here are alpha
> contracts. Deterministic canonical reports and local runtime models are CI
> artifacts, not production evidence; promotion requires live VM/container or
> Kubernetes evidence recorded in `docs/ai-blaise/PRODUCTION_READINESS_AUDIT.md`
> and guarded by `ci/ai-blaise/production-gap-audit.sh`.

CloudNativePG operand image contract for Citus, the companion SQL fallback, and
the bundled extension policy. This directory is not production evidence that
every binary package in the manifest is installed in a runnable operand image
on its own; `FEATURE: Bundle1` promotion to production-ready requires a real
image build smoke that source-builds the nine Bundle1 extensions missing from
PGDG for PostgreSQL 17 and verifies the required extension control files and
initdb extension creation end to end. The smoke under
`ci/ai-blaise/sql-extension-smoke.sh` with `BUNDLE1_BUILD_IMAGE=1` is the live
gate.

## Contract

- `extension-manifest.tsv` is the source of truth for required, optional, and
  hard-blocked extensions from the V2 plan.
- `shared-preload-libraries.conf` records the load-order-sensitive preload
  contract.
- `initdb.d/00-ai-blaise-extensions.sql` creates the required extension set in a
  deterministic order and intentionally fails when a required extension control
  file is absent.
- `extensions/ai_blaise_citus.control` and
  `extensions/ai_blaise_citus--0.1.0.sql` install the companion SQL fallback
  surface so `CREATE EXTENSION ai_blaise_citus` exposes feature-status and
  pgrx-compatible Timescale-on-Citus plan helpers, including the TS5
  time-range shard-pruner helper, before the compiled pgrx library is present.
- `extensions/pg_warm.control` and `extensions/pg_warm--0.1.0.sql` install a
  thin in-tree `pg_warm` extension that wraps the PG core `pg_prewarm`
  contrib extension. There is no upstream "pg_warm" project; the shim gives
  the V2 catalog a stable extension name for the R11 replica cold-start
  cache-warming contract.
- `Dockerfile` is a multi-stage source-build for the nine Bundle1 extensions
  PGDG does not ship for PostgreSQL 17 (`citus`, `pgsodium`, `topn`,
  `pg_jsonschema`, `pg_graphql`, `pg_search`, `plrust`, `plv8`, and the
  in-tree `pg_warm` shim). The two final targets are
  `bundle1-final-light` (six light + base + apt extensions) and
  `bundle1-final-full` (adds `plv8`, `plrust`, `pg_search`). The default
  target is `bundle1-final-full`.
- `bundle1-source-build-evidence.tsv` is appended by the source-build smoke
  with timestamp, git SHA, OCI image digest, build target, and extension list.
- `ci/ai-blaise/image-check.sh` validates the image contract in CI and asserts
  that every Bundle1 source-build stage and pinned upstream tag is present.
