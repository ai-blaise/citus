# Bundled Extensions

The canonical operand-image extension contract lives in
`images/citus-pg-overlay/extension-manifest.tsv`, and the operand image
`images/citus-pg-overlay/Dockerfile` source-builds the nine Bundle1
extensions that are not available from PGDG for PostgreSQL 17 in dedicated
multi-stage builder layers. `FEATURE: Bundle1` is promoted to production-ready
once the in-tree source-build smoke
(`ci/ai-blaise/sql-extension-smoke.sh` with `BUNDLE1_BUILD_IMAGE=1`) has
recorded a live evidence row under
`images/citus-pg-overlay/bundle1-source-build-evidence.tsv` capturing the
operand image's digest, git SHA, build target, and CREATE EXTENSION coverage.

## Source-built Bundle1 packages

The following nine extensions are not shipped by PGDG for PostgreSQL 17 and
are compiled from pinned upstream tags inside the operand image's multi-stage
build. The pin lives in `images/citus-pg-overlay/Dockerfile` as a top-level
ARG and is mirrored as an OCI image label so the published operand image
records the exact build inputs.

| Extension | Upstream | Tag | License | Build stage |
|---|---|---|---|---|
| citus | this fork (tracks citusdata/citus v13.3.0) | v13.3.0 | AGPL-3.0 | `build-citus` |
| pgsodium | michelp/pgsodium | v3.1.9 | PostgreSQL | `build-pgsodium` |
| topn | citusdata/postgresql-topn | v2.7.0 | AGPL-3.0 | `build-topn` |
| pg_jsonschema | supabase/pg_jsonschema | v0.3.4 | Apache-2.0 | `build-pg-jsonschema` |
| pg_graphql | supabase/pg_graphql | v1.6.1 | Apache-2.0 | `build-pg-graphql` |
| pg_search (ParadeDB) | paradedb/paradedb | v0.20.11 | AGPL-3.0 | `build-pg-search` |
| plrust | pgcentralfoundation/plrust | v1.2.8 | PostgreSQL | `build-plrust` |
| plv8 | plv8/plv8 | v3.2.4 | PostgreSQL | `build-plv8` |
| pg_warm | this repo (`images/citus-pg-overlay/extensions/pg_warm--0.1.0.sql`) | local | PostgreSQL | `bundle1-final-light` shim wrapping the core `pg_prewarm` contrib extension |

The Dockerfile defines two named final targets so PR CI does not have to pay
the full source-build cost:

- `bundle1-final-light` adds the four light source-builds plus citus and the
  pg_warm shim on top of `bundle1-final-base`. Used by the PR-time smoke when
  `BUNDLE1_BUILD_IMAGE=1` is set and completes in ~10-15 minutes on a
  2-core / 7 GiB worker.
- `bundle1-final-full` extends `bundle1-final-light` with the three heavy
  source-builds (`pg_search`, `plrust`, `plv8`) and is the default Dockerfile
  target. It is the production build path; the smoke covers it when both
  `BUNDLE1_BUILD_IMAGE=1` and `BUNDLE1_BUILD_HEAVY=1` are set and completes
  in 1-3 hours on the same worker.

The pg_warm surface is intentionally a thin in-tree SQL extension that
delegates to the PG core `pg_prewarm` contrib extension. There is no
upstream "pg_warm" project; the local shim gives the V2 catalog a stable
extension name so `CREATE EXTENSION pg_warm` succeeds against the operand
image and the R11 replica cold-start cache-warming contract has a real
SQL surface.

## Required Bundle

The required bundle records the intended extension set for ai-blaise/citus
Postgres operand images. It covers the V2 plan's mandatory Citus, TimescaleDB,
vector, search, graph, JSON Schema, observability, security, geo, and
online-maintenance substrates.

Required entries are statically validated by `ci/ai-blaise/image-check.sh`.
Cluster initialization uses
`images/citus-pg-overlay/initdb.d/00-ai-blaise-extensions.sql` as the
deterministic extension creation order and intentionally fails when a required
extension control file is absent.

The overlay also installs `ai_blaise_citus`, a local SQL fallback companion
extension. It exposes `companion_feature_status()` plus pgrx-compatible
Timescale-on-Citus plan helpers, including distributed hypertable and
time-range shard-pruner plans, in the operand image even before the compiled
pgrx companion library is loaded, so smoke tests and operators have a stable
extension name to target.

## Optional Bundle

Optional entries are chart- or image-build flags. They are kept in the same
manifest so licensing, packaging, and hard-block rules remain reviewable in one
place.

## Hard Blocks

Hard-block entries are not bundled because they replace heap access methods,
install conflicting planner or transaction hooks, or compete with Citus shard
management. Adding a blocked extension to the required or optional bundle must
first change the manifest and explain the conflict resolution in an ADR.
