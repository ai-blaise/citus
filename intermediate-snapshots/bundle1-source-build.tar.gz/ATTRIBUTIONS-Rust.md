# Rust Attributions

The operand image (`images/citus-pg-overlay/Dockerfile`) source-builds four
Bundle1 PostgreSQL extensions from Rust workspaces. Each upstream is recorded
here together with the pinned tag, license, and the `cargo pgrx` toolchain
version used during the build.

## Bundle1 Rust extensions

| Extension | Upstream | Tag | License | Build toolchain | NOTICE |
|---|---|---|---|---|---|
| pg_jsonschema | https://github.com/supabase/pg_jsonschema | v0.3.4 | Apache-2.0 | `cargo-pgrx 0.12.9` | Build stage `build-pg-jsonschema`. License text in upstream `LICENSE`. |
| pg_graphql | https://github.com/supabase/pg_graphql | v1.6.1 | Apache-2.0 | `cargo-pgrx 0.12.9` | Build stage `build-pg-graphql`. License text in upstream `LICENSE`. |
| pg_search | https://github.com/paradedb/paradedb | v0.20.11 | AGPL-3.0 | `cargo-pgrx 0.12.9` | Build stage `build-pg-search`. ParadeDB workspace under AGPL-3.0; redistribution requires source disclosure on request. License text in upstream `LICENSE`. |
| plrust | https://github.com/pgcentralfoundation/plrust | v1.2.8 | PostgreSQL | `cargo-pgrx 0.11.4` with `llvm-tools-preview` | Build stage `build-plrust`. License text in upstream `LICENSE`. |

## Build-time Rust dependencies

The Bundle1 build stages pull `rustup` from `https://sh.rustup.rs` and
install the stable toolchain plus pinned `cargo-pgrx` releases shown above.
These dependencies are tied to the build stage layers only and do not ship
runtime artifacts inside the operand image beyond the compiled `.so` and
`.sql` files emitted by `cargo pgrx package`.

| Build dependency | License | Source |
|---|---|---|
| Rust standard library | MIT / Apache-2.0 | https://github.com/rust-lang/rust |
| cargo-pgrx | MIT / Apache-2.0 | https://github.com/pgcentralfoundation/pgrx |
| pgrx | MIT / Apache-2.0 | https://github.com/pgcentralfoundation/pgrx |

## Other Rust components in this repository

The Cargo workspace under this repository (`companion/`, `sidecar/*/`,
`pool/`, `operator/`, `e2e/`, `tools/*/`, etc.) is built and licensed
together with the Citus fork under AGPL-3.0. Transitive Cargo dependencies
are pinned in `Cargo.lock`. License compatibility is enforced by
`ci/ai-blaise/license-check.sh` and the integration rules recorded in
`docs/ai-blaise/LICENSE_AUDIT.md`.
