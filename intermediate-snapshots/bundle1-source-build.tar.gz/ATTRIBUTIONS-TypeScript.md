# TypeScript / JavaScript Attributions

The operand image (`images/citus-pg-overlay/Dockerfile`) source-builds one
Bundle1 PostgreSQL extension that embeds a JavaScript runtime, plus a couple
of edge-function sidecar runtimes that are consumed but not vendored.

## Bundle1 JavaScript-runtime extensions

| Extension | Upstream | Tag | License | NOTICE |
|---|---|---|---|---|
| plv8 | https://github.com/plv8/plv8 | v3.2.4 | PostgreSQL | Build stage `build-plv8`. Bundles a snapshot of Google's V8 JavaScript engine via the upstream build script (V8 itself is BSD-3-Clause). License text in upstream `LICENSE` and the embedded V8 vendor tree. |

## V8 attribution

`plv8` embeds the V8 JavaScript engine produced by the Chromium project at
https://chromium.googlesource.com/v8/v8. V8 is distributed under the
BSD-3-Clause license. The plv8 v3.2.4 build pulls the V8 sources defined by
the upstream `Makefile`'s `V8_VERSION` pin; redistributors should preserve the
V8 copyright notice from the upstream V8 source tree alongside any
redistribution of the compiled `plv8.so`.

## Other JavaScript / TypeScript components in this repository

The edge-function runtime surface is sidecar-shaped, not bundled into the
operand image:

| Component | License | Posture |
|---|---|---|
| Deno | MIT | Used as an edge-function runtime sidecar; not vendored into the operand image. |
| Bun | MIT | Used as an optional edge-function runtime sidecar; not vendored into the operand image. |

`docs/ai-blaise/LICENSE_AUDIT.md` records the integration rule for each
sidecar; the operand image's Bundle1 surface does not depend on either Deno
or Bun.
