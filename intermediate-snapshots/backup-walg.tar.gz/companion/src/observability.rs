// FEATURE: O1
// FEATURE: O2
// FEATURE: O3
// FEATURE: R4
// FEATURE: B1
// FEATURE: B3

use std::error::Error;
use std::fmt;

#[derive(Debug, Clone, Eq, PartialEq)]
pub struct OperationsGuardrailPlan {
    pub query_percentiles: QueryPercentileViewPlan,
    pub local_activity_stats: LocalActivityStatPlan,
    pub replication_lag: ReplicationLagPlan,
    pub idle_transaction_detector: IdleTransactionDetectorPlan,
}

impl OperationsGuardrailPlan {
    pub fn validate(&self) -> Result<(), ObservabilityError> {
        self.query_percentiles.validate()?;
        self.local_activity_stats.validate()?;
        self.replication_lag.validate()?;
        self.idle_transaction_detector.validate()
    }
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub struct QueryPercentileViewPlan {
    pub view_name: String,
    pub source_view: String,
    pub percentiles: Vec<LatencyPercentile>,
}

impl QueryPercentileViewPlan {
    pub fn validate(&self) -> Result<(), ObservabilityError> {
        validate_required("query_percentiles.view_name", &self.view_name)?;
        validate_required("query_percentiles.source_view", &self.source_view)?;
        if self.percentiles.is_empty() {
            return Err(ObservabilityError::MissingRequiredField(
                "query_percentiles.percentiles",
            ));
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum LatencyPercentile {
    P95,
    P99,
    P999,
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub struct LocalActivityStatPlan {
    pub view_name: String,
    pub sample_interval_seconds: u32,
}

impl LocalActivityStatPlan {
    pub fn validate(&self) -> Result<(), ObservabilityError> {
        validate_required("local_activity_stats.view_name", &self.view_name)?;
        if self.sample_interval_seconds == 0 {
            return Err(ObservabilityError::InvalidSampleInterval);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub struct ReplicationLagPlan {
    pub view_name: String,
    pub regions: Vec<String>,
    pub max_lag_ms: u64,
}

impl ReplicationLagPlan {
    pub fn validate(&self) -> Result<(), ObservabilityError> {
        validate_required("replication_lag.view_name", &self.view_name)?;
        validate_required_list("replication_lag.regions", &self.regions)?;
        if self.max_lag_ms == 0 {
            return Err(ObservabilityError::InvalidLagBudget);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub struct IdleTransactionDetectorPlan {
    pub max_idle_seconds: u32,
}

impl IdleTransactionDetectorPlan {
    pub fn validate(&self) -> Result<(), ObservabilityError> {
        if self.max_idle_seconds == 0 {
            return Err(ObservabilityError::InvalidIdleLimit);
        }
        Ok(())
    }
}

/// Observability plan for the backup sidecar HTTP surface.
///
/// Renders the SQL view contracts that companion installs to read from
/// `sidecar/backup`'s real WAL-G runtime: `pg_backup_status` reads the
/// latest base-backup artifact and `pg_wal_archive_lag` reports the gap
/// between the latest archived WAL segment and the live primary write LSN.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct BackupObservabilityPlan {
    pub status_view: BackupStatusViewPlan,
    pub wal_archive_lag_view: WalArchiveLagViewPlan,
}

impl BackupObservabilityPlan {
    pub fn validate(&self) -> Result<(), ObservabilityError> {
        self.status_view.validate()?;
        self.wal_archive_lag_view.validate()
    }
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub struct BackupStatusViewPlan {
    pub view_name: String,
    pub sidecar_http_endpoint: String,
    pub max_age_seconds: u32,
}

impl BackupStatusViewPlan {
    pub fn validate(&self) -> Result<(), ObservabilityError> {
        validate_required("backup_status.view_name", &self.view_name)?;
        validate_required(
            "backup_status.sidecar_http_endpoint",
            &self.sidecar_http_endpoint,
        )?;
        if self.max_age_seconds == 0 {
            return Err(ObservabilityError::InvalidSampleInterval);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub struct WalArchiveLagViewPlan {
    pub view_name: String,
    pub sidecar_http_endpoint: String,
    pub max_lag_ms: u64,
}

impl WalArchiveLagViewPlan {
    pub fn validate(&self) -> Result<(), ObservabilityError> {
        validate_required("wal_archive_lag.view_name", &self.view_name)?;
        validate_required(
            "wal_archive_lag.sidecar_http_endpoint",
            &self.sidecar_http_endpoint,
        )?;
        if self.max_lag_ms == 0 {
            return Err(ObservabilityError::InvalidLagBudget);
        }
        Ok(())
    }
}

pub fn canonical_backup_observability_plan() -> BackupObservabilityPlan {
    BackupObservabilityPlan {
        status_view: BackupStatusViewPlan {
            view_name: "companion.pg_backup_status".to_string(),
            sidecar_http_endpoint: "http://backup-sidecar:8080/backups".to_string(),
            max_age_seconds: 24 * 60 * 60,
        },
        wal_archive_lag_view: WalArchiveLagViewPlan {
            view_name: "companion.pg_wal_archive_lag".to_string(),
            sidecar_http_endpoint: "http://backup-sidecar:8080/wal/status".to_string(),
            max_lag_ms: 60_000,
        },
    }
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub enum ObservabilityError {
    InvalidIdleLimit,
    InvalidLagBudget,
    InvalidSampleInterval,
    MissingRequiredField(&'static str),
}

impl fmt::Display for ObservabilityError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidIdleLimit => {
                write!(formatter, "max_idle_seconds must be greater than zero")
            }
            Self::InvalidLagBudget => write!(formatter, "max_lag_ms must be greater than zero"),
            Self::InvalidSampleInterval => {
                write!(
                    formatter,
                    "sample_interval_seconds must be greater than zero"
                )
            }
            Self::MissingRequiredField(field) => {
                write!(formatter, "{field} must not be empty")
            }
        }
    }
}

impl Error for ObservabilityError {}

fn validate_required(field: &'static str, value: &str) -> Result<(), ObservabilityError> {
    if value.trim().is_empty() {
        return Err(ObservabilityError::MissingRequiredField(field));
    }
    Ok(())
}

fn validate_required_list(
    field: &'static str,
    values: &[String],
) -> Result<(), ObservabilityError> {
    if values.is_empty() || values.iter().any(|value| value.trim().is_empty()) {
        return Err(ObservabilityError::MissingRequiredField(field));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn valid_operations_guardrail_plan_passes() {
        let plan = OperationsGuardrailPlan {
            query_percentiles: QueryPercentileViewPlan {
                view_name: "companion.pg_stat_statements_p95".to_string(),
                source_view: "pg_stat_statements".to_string(),
                percentiles: vec![LatencyPercentile::P95, LatencyPercentile::P99],
            },
            local_activity_stats: LocalActivityStatPlan {
                view_name: "companion.pg_stat_local_activity".to_string(),
                sample_interval_seconds: 15,
            },
            replication_lag: ReplicationLagPlan {
                view_name: "companion.pg_dist_replication_lag".to_string(),
                regions: vec!["us-east-1".to_string(), "us-west-2".to_string()],
                max_lag_ms: 5_000,
            },
            idle_transaction_detector: IdleTransactionDetectorPlan {
                max_idle_seconds: 60,
            },
        };

        assert_eq!(plan.validate(), Ok(()));
    }

    #[test]
    fn query_percentiles_require_targets() {
        let plan = QueryPercentileViewPlan {
            view_name: "companion.pg_stat_statements_p95".to_string(),
            source_view: "pg_stat_statements".to_string(),
            percentiles: Vec::new(),
        };

        assert_eq!(
            plan.validate(),
            Err(ObservabilityError::MissingRequiredField(
                "query_percentiles.percentiles"
            ))
        );
    }

    #[test]
    fn idle_detector_requires_positive_limit() {
        let plan = IdleTransactionDetectorPlan {
            max_idle_seconds: 0,
        };

        assert_eq!(plan.validate(), Err(ObservabilityError::InvalidIdleLimit));
    }

    #[test]
    fn canonical_backup_observability_plan_validates() {
        let plan = canonical_backup_observability_plan();
        assert_eq!(plan.validate(), Ok(()));
        assert_eq!(plan.status_view.view_name, "companion.pg_backup_status");
        assert_eq!(
            plan.wal_archive_lag_view.view_name,
            "companion.pg_wal_archive_lag"
        );
    }

    #[test]
    fn backup_status_view_requires_endpoint() {
        let mut plan = canonical_backup_observability_plan();
        plan.status_view.sidecar_http_endpoint = " ".to_string();
        assert_eq!(
            plan.validate(),
            Err(ObservabilityError::MissingRequiredField(
                "backup_status.sidecar_http_endpoint"
            ))
        );
    }

    #[test]
    fn wal_archive_lag_view_requires_positive_lag_budget() {
        let mut plan = canonical_backup_observability_plan();
        plan.wal_archive_lag_view.max_lag_ms = 0;
        assert_eq!(plan.validate(), Err(ObservabilityError::InvalidLagBudget));
    }
}
