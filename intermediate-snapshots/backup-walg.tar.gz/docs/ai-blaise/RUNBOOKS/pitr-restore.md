# PITR Restore Runbook

> Production boundary: this runbook drives the production sidecar/backup runtime
> for `FEATURE: B3` and depends on `FEATURE: B1` (real WAL-G orchestration). The
> deterministic canonical reports remain CI artifacts; live PostgreSQL recovery
> is the operator's responsibility once the sidecar emits a `succeeded` PITR job.

## When to use

Use this runbook when a cluster must be restored to a specific UTC point-in-time
without overwriting the production primary. Typical triggers:

- A logical corruption (bad migration, accidental `UPDATE`/`DELETE`) reported
  inside the WAL archive window for the cluster.
- A consistency probe (replication lag, application-level audit) that needs a
  read-only branch at a known-good timestamp.
- Disaster recovery rehearsal validating the WAL-G + Backup CRD pipeline.

If the cluster needs a full data-loss failover instead of PITR, see
`disaster-recovery.md`.

## Preconditions

1. The cluster's `Backup` CRD has been reconciled with a non-empty
   `archive_uri`, `schedule`, and (if encrypted) `encryption.kms_key_ref`.
2. The `sidecar/backup` HTTP runtime is reachable from the operator pod and
   exposes `/healthz`, `/readyz`, and `/metrics` (verify via
   `kubectl port-forward` or the operator-managed service).
3. The WAL archive window covers the desired target time. Confirm with
   `curl http://<sidecar>/wal/status` and inspect `oldest_wal_time` and
   `latest_wal_time`.
4. The recovery destination directory (`AI_BLAISE_BACKUP_RESTORE_ROOT/<target_cluster>`)
   is empty or does not exist; the sidecar refuses to write into an existing
   non-empty pgdata.

## Procedure

### 1. Confirm the WAL archive window

```sh
curl -fsS http://<sidecar>/wal/status | jq .
```

Expected output:

```json
{
  "oldest_wal_time": "2026-05-18T00:00:00Z",
  "latest_wal_time": "2026-05-21T14:00:00Z",
  "detail": "...",
  "elapsed_ms": 42
}
```

If the desired `target_time` falls outside `[oldest_wal_time, latest_wal_time]`,
the sidecar will refuse the restore with `PitrTargetOutsideWindow`. Promote a
new base backup with `POST /backups/run` if the window is too short.

### 2. Submit the restore request

```sh
curl -fsS -X POST http://<sidecar>/pitr/restore \
  -H 'content-type: application/json' \
  -d '{
        "cluster": "prod",
        "source_archive_uri": "s3://backups/prod",
        "target_time": "2026-05-19T12:00:00Z",
        "target_cluster": "restore-prod"
      }'
```

The sidecar validates the plan, runs `wal-g backup-fetch <target_dir> LATEST
--target-time <target>`, and records the job at `/pitr/status/<job_id>`. The
job id is returned in the `202 Accepted` response.

### 3. Wait for the job to succeed

```sh
curl -fsS http://<sidecar>/pitr/status/<job_id> | jq .status
```

Expected: `"succeeded"`. A `"failed"` status carries a `status_detail` string
that quotes the WAL-G stderr — escalate to the cluster operator before
retrying so the operand image, credentials, and archive can be checked.

### 4. Start the queryable branch (optional, for B4)

If the restore is to be served as a read-only branch:

```sh
curl -fsS -X POST http://<sidecar>/branches/queryable \
  -H 'content-type: application/json' \
  -d '{
        "branch_name": "prod-at-noon",
        "source_archive_uri": "s3://backups/prod",
        "target_time": "2026-05-19T12:00:00Z",
        "port": 6543
      }'
```

The sidecar materializes `postgresql.auto.conf` with `recovery_target_time`,
`recovery_target_action = 'pause'`, and `default_transaction_read_only = on`.
The operator-controlled image then runs `pg_ctl -D <data_dir> start` to bring
the read-only PostgreSQL instance online; the sidecar returns the
`data_dir`, port, and recovery time.

### 5. Promote or discard

- To **promote** the restore as the new primary, hand off the
  `target_directory` to the operator's `CitusCluster.spec.restoreFrom` field
  (see `operator/src/crds/citus_cluster.rs`) and follow `upgrade.md` for
  cutover.
- To **discard** the restore, stop the queryable branch via `pg_ctl stop` and
  delete the data directory. The sidecar drops the branch record once a
  follow-up `DELETE /branches/queryable/<branch_name>` is processed (future
  enhancement, tracked in `NEW_FEATURES.md`).

## Failure modes

| Condition | Sidecar response | Operator action |
|-----------|-------------------|-----------------|
| `target_time` outside WAL window | `400` + `PitrTargetOutsideWindow` | Promote a fresh base backup; rerun. |
| Empty or wrong `source_archive_uri` | `400` + `ArchiveMismatch` | Confirm `Backup` CRD `archive_uri` and retry with the matching value. |
| `wal-g backup-fetch` exits non-zero | `job.status = "failed"` with `status_detail` | Inspect the operand image WAL-G logs, fix credentials/secrets, then retry. |
| `default_transaction_read_only` not in branch `auto.conf` | Read-only probe fails | Re-run `POST /branches/queryable`; verify the operand image picked up the regenerated config. |

## Production evidence

`ci/ai-blaise/sidecar-backup-smoke.sh` exercises every step above against a
deterministic WAL-G stub: a target outside the configured window is rejected
with the structured error, an in-window target succeeds via
`POST /pitr/restore`, the status endpoint returns `succeeded`, and the
queryable-branch endpoint materializes the configuration plus dedupes by
branch name. Live operand-image cutover and live WAL-G credentials are the
operator's responsibility.
