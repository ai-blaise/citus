#!/usr/bin/env bash
set -euo pipefail

# FEATURE: Auth1 Auth2 Auth3 Auth4 Auth5

repo_root="$(git rev-parse --show-toplevel)"
cd "${repo_root}"

python3 <<'PY'
import base64
import hashlib
import hmac
import http.client
import json
import os
import socket
import struct
import subprocess
import sys
import time


def free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def request(host: str, port: int, method: str, path: str, body=None):
    conn = http.client.HTTPConnection(host, port, timeout=10)
    headers = {}
    if body is not None:
        headers["content-type"] = "application/json"
    conn.request(method, path, body=body, headers=headers)
    response = conn.getresponse()
    data = response.read().decode("utf-8")
    conn.close()
    return response.status, data


def base32_decode(text: str) -> bytes:
    return base64.b32decode(text + "=" * ((8 - len(text) % 8) % 8))


def totp_code(secret: bytes, counter: int, digits: int = 6) -> str:
    counter_bytes = struct.pack(">Q", counter)
    digest = hmac.new(secret, counter_bytes, hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    binary = (
        ((digest[offset] & 0x7F) << 24)
        | (digest[offset + 1] << 16)
        | (digest[offset + 2] << 8)
        | digest[offset + 3]
    )
    code = binary % (10 ** digits)
    return f"{code:0{digits}d}"


host = "127.0.0.1"
port = free_port()
env = os.environ.copy()
env["AI_BLAISE_LISTEN_ADDR"] = f"{host}:{port}"
env["AI_BLAISE_AUTH_ISSUER"] = "https://auth.example.com"
env["AI_BLAISE_AUTH_AUDIENCE"] = "postgres"
env["AI_BLAISE_AUTH_TTL_SECONDS"] = "5"
env["AI_BLAISE_AUTH_HS256_SECRET"] = "ai-blaise-auth-smoke-secret-key"

proc = subprocess.Popen(
    ["cargo", "run", "-q", "-p", "ai_blaise_citus_sidecar_auth", "--", "serve"],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    text=True,
    env=env,
)


try:
    for _ in range(120):
        try:
            status, body = request(host, port, "GET", "/readyz")
            if status == 200 and '"component":"auth-sidecar"' in body:
                break
        except OSError:
            pass
        if proc.poll() is not None:
            stderr = proc.stderr.read() if proc.stderr else ""
            raise AssertionError(f"auth sidecar exited early: {stderr}")
        time.sleep(0.5)
    else:
        raise AssertionError("auth sidecar did not become ready")

    status, body = request(host, port, "GET", "/metrics")
    assert status == 200, body
    assert 'ai_blaise_sidecar_ready{component="auth-sidecar"} 1' in body

    register_body = json.dumps(
        {
            "username": "alice",
            "password": "hunter2-correct-horse",
            "role": "authenticated",
            "tenant_id": "tenant-a",
        }
    )
    status, body = request(host, port, "POST", "/auth/users", register_body)
    assert status == 201, f"register: {status} {body}"

    status, body = request(
        host,
        port,
        "POST",
        "/auth/login",
        json.dumps({"username": "alice", "password": "hunter2-correct-horse"}),
    )
    assert status == 200, f"login: {status} {body}"
    login = json.loads(body)
    access_token = login["access_token"]
    refresh_token = login["refresh_token"]
    assert access_token.count(".") == 2
    assert login["mfa_required"] is False

    status, body = request(
        host, port, "POST", "/auth/verify", json.dumps({"token": access_token})
    )
    assert status == 200, f"verify: {status} {body}"
    verified = json.loads(body)
    assert verified["sub"] == "alice"
    assert verified["tenant_id"] == "tenant-a"
    assert verified["role"] == "authenticated"
    assert verified["iss"] == "https://auth.example.com"
    assert verified["aud"] == "postgres"

    status, body = request(
        host, port, "POST", "/auth/introspect", json.dumps({"token": access_token})
    )
    assert status == 200, f"introspect active: {status} {body}"
    introspected = json.loads(body)
    assert introspected["active"] is True
    assert introspected["sub"] == "alice"

    # Refresh path: exchange refresh token for a fresh access token.
    status, body = request(
        host,
        port,
        "POST",
        "/auth/refresh",
        json.dumps({"refresh_token": refresh_token}),
    )
    assert status == 200, f"refresh: {status} {body}"
    refreshed = json.loads(body)
    refreshed_token = refreshed["access_token"]
    assert refreshed_token != access_token
    status, body = request(
        host, port, "POST", "/auth/verify", json.dumps({"token": refreshed_token})
    )
    assert status == 200, f"verify refreshed: {status} {body}"

    # Bad / tampered token rejected.
    bad_token = access_token[:-2] + ("AA" if access_token[-2:] != "AA" else "BB")
    status, body = request(
        host, port, "POST", "/auth/verify", json.dumps({"token": bad_token})
    )
    assert status == 401, f"tampered verify: {status} {body}"

    # Token expires within AI_BLAISE_AUTH_TTL_SECONDS=5 seconds; wait it out
    # and confirm verify now returns 401.
    print("waiting for access token to expire...", flush=True)
    time.sleep(12)
    status, body = request(
        host, port, "POST", "/auth/verify", json.dumps({"token": access_token})
    )
    assert status == 401, f"expired verify: {status} {body}"
    status, body = request(
        host, port, "POST", "/auth/verify", json.dumps({"token": refreshed_token})
    )
    assert status == 401, f"expired refreshed verify: {status} {body}"

    # MFA TOTP enroll + verify.
    status, body = request(
        host,
        port,
        "POST",
        "/auth/mfa/totp/enroll",
        json.dumps({"username": "alice"}),
    )
    assert status == 200, f"totp enroll: {status} {body}"
    enrollment = json.loads(body)
    assert enrollment["digits"] == 6
    assert enrollment["period_seconds"] == 30
    secret_b32 = enrollment["secret_base32"]
    secret_bytes = base32_decode(secret_b32)
    counter = int(time.time()) // 30
    code = totp_code(secret_bytes, counter)

    status, body = request(
        host,
        port,
        "POST",
        "/auth/mfa/totp/verify",
        json.dumps({"username": "alice", "code": code}),
    )
    assert status == 200, f"totp verify: {status} {body}"

    # Wrong code rejected.
    status, body = request(
        host,
        port,
        "POST",
        "/auth/mfa/totp/verify",
        json.dumps({"username": "alice", "code": "000000"}),
    )
    assert status == 401, f"totp wrong code: {status} {body}"

    # Login now requires MFA.
    status, body = request(
        host,
        port,
        "POST",
        "/auth/login",
        json.dumps({"username": "alice", "password": "hunter2-correct-horse"}),
    )
    assert status == 401, f"login without totp: {status} {body}"

    counter = int(time.time()) // 30
    code = totp_code(secret_bytes, counter)
    status, body = request(
        host,
        port,
        "POST",
        "/auth/login",
        json.dumps(
            {
                "username": "alice",
                "password": "hunter2-correct-horse",
                "totp_code": code,
            }
        ),
    )
    assert status == 200, f"login with totp: {status} {body}"
    mfa_login = json.loads(body)
    assert mfa_login["mfa_verified"] is True

    # Logout invalidates the JTI.
    status, body = request(
        host,
        port,
        "POST",
        "/auth/logout",
        json.dumps({"token": mfa_login["access_token"]}),
    )
    assert status == 200, f"logout: {status} {body}"
    status, body = request(
        host,
        port,
        "POST",
        "/auth/verify",
        json.dumps({"token": mfa_login["access_token"]}),
    )
    assert status == 401, f"verify after logout: {status} {body}"

    # WebAuthn + OIDC remain alpha; ensure the endpoints respond with 501.
    for path in (
        "/auth/mfa/webauthn/register",
        "/auth/mfa/webauthn/finish",
    ):
        status, body = request(host, port, "POST", path, "{}")
        assert status == 501, f"{path}: {status} {body}"

    for path in ("/auth/oidc/login", "/auth/oidc/callback"):
        status, body = request(host, port, "GET", path)
        assert status == 501, f"{path}: {status} {body}"

finally:
    proc.terminate()
    try:
        proc.wait(timeout=20)
    except subprocess.TimeoutExpired:
        proc.kill()
        proc.wait(timeout=20)

if proc.returncode not in (0, -15):
    stderr = proc.stderr.read() if proc.stderr else ""
    print(stderr, file=sys.stderr)
    raise SystemExit(proc.returncode)

print("ai_blaise_citus_sidecar_auth HTTP smoke passed")
PY
