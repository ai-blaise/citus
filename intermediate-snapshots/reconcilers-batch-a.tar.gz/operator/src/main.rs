// FEATURE: A8
// FEATURE: B2
// FEATURE: B6
// FEATURE: C4
// FEATURE: C5
// FEATURE: C6
// FEATURE: C7
// FEATURE: C8
// FEATURE: C9
// FEATURE: EF3
// FEATURE: F1
// FEATURE: M3
// FEATURE: MR1
// FEATURE: MR2
// FEATURE: MR4
// FEATURE: MR8
// FEATURE: O5
// FEATURE: R2
// FEATURE: R7
// FEATURE: S2
// FEATURE: S4
// FEATURE: S10
// FEATURE: S11
// FEATURE: Search2
// FEATURE: Search7
// FEATURE: TO1
// FEATURE: TO2
// FEATURE: TO5
// FEATURE: TS7
// FEATURE: WH1

use ai_blaise_citus_operator::{
    BackupEncryption, BackupProvider, BackupReconcilePlan, BackupSpec, BackupTarget, BranchSpec,
    BranchStorageSpec, BranchType, ChunkingSpec, ChunkingStrategy, CitusClusterSpec, CitusTopology,
    CompressionPolicy, ConflictClass, ConflictPolicySpec, ConflictResolution,
    ContinuousAggregateSpec, EmbeddingProvider, FederationConnection, FederationSpec,
    FederationType, FunctionEvent, FunctionRuntime, FunctionSource, FunctionSpec, FunctionTrigger,
    HypertableReconcilePlan, HypertableSpec, MigrationConflictAction, MigrationSpec, MigrationType,
    PlacementPolicy, PoolSpec, RegionReconcilePlan, RegionSpec, RepackStrategy,
    ResourceRequirements, RetentionPolicy, ScheduledRepackSpec, SearchColumnKind, SearchColumnSpec,
    SearchIndexSpec, SearchScorer, ShardGroupSpec, SidecarDeploymentSpec, SidecarDeploymentType,
    SidecarSpec, SidecarType, SurvivalGoalReconcilePlan, SurvivalGoalSpec, SurvivalGoalType,
    TenantQuotas, TenantReconcilePlan, TenantSpec, UnsatisfiablePlacementAction,
    VectorDestinationSpec, VectorizerScheduleMode, VectorizerSchedulingSpec, VectorizerSpec,
    WebhookEvent, WebhookRetryPolicy, WebhookSpec,
};
use ai_blaise_citus_sidecar_shared::run_probe_server;
use std::env;
use std::error::Error;
use std::process;

const CANONICAL_OPERATOR_CRDS: usize = 17;
const V2_OPERATOR_CATALOG_GATES: usize = 13;

fn main() {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.iter().any(|arg| arg == "--help" || arg == "-h") {
        print_usage();
        return;
    }
    if args == ["serve"] {
        run_server("operator", "0.0.0.0:8080");
        return;
    }

    match args.as_slice() {
        [] => run_canonical(),
        [command] if command == "run-canonical" => run_canonical(),
        _ => {
            eprintln!("operator: unknown command");
            print_usage();
            process::exit(2);
        }
    }
}

fn run_canonical() {
    let report = canonical_operator_execution_report().unwrap_or_else(|error| {
        eprintln!("operator: canonical execution failed: {error}");
        process::exit(1);
    });

    println!(
        "crds\tcluster_workers\tcluster_sidecars\tshards\thypertable_sql_plans\thypertable_apply_steps\tcatalog_gates\tbackup_retention_days\tvector_dimensions\tfunction_triggers\twebhook_events\tsearch_columns\tsidecar_replicas\ttenant_apply_steps\tregion_apply_steps\tsurvival_goal_apply_steps\tbackup_apply_steps"
    );
    println!(
        "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
        report.crds,
        report.cluster_workers,
        report.cluster_sidecars,
        report.shards,
        report.hypertable_sql_plans,
        report.hypertable_apply_steps,
        report.catalog_gates,
        report.backup_retention_days,
        report.vector_dimensions,
        report.function_triggers,
        report.webhook_events,
        report.search_columns,
        report.sidecar_replicas,
        report.tenant_apply_steps,
        report.region_apply_steps,
        report.survival_goal_apply_steps,
        report.backup_apply_steps,
    );
}

fn print_usage() {
    println!("usage: operator [serve|run-canonical]");
}

fn run_server(component: &str, default_addr: &str) {
    if let Err(error) = run_probe_server(component, default_addr) {
        eprintln!("{component}: probe server failed: {error}");
        process::exit(1);
    }
}

#[derive(Debug, Clone, Eq, PartialEq)]
struct OperatorExecutionReport {
    crds: usize,
    cluster_workers: u32,
    cluster_sidecars: usize,
    shards: u32,
    hypertable_sql_plans: usize,
    hypertable_apply_steps: usize,
    catalog_gates: usize,
    backup_retention_days: u32,
    vector_dimensions: u32,
    function_triggers: usize,
    webhook_events: usize,
    search_columns: usize,
    sidecar_replicas: u32,
    tenant_apply_steps: usize,
    region_apply_steps: usize,
    survival_goal_apply_steps: usize,
    backup_apply_steps: usize,
}

fn canonical_operator_execution_report() -> Result<OperatorExecutionReport, Box<dyn Error>> {
    let cluster = canonical_cluster_spec();
    cluster.validate()?;

    let shard_group = canonical_shard_group_spec();
    shard_group.validate()?;

    let hypertable = canonical_hypertable_spec();
    hypertable.validate()?;
    let hypertable_plan = HypertableReconcilePlan::try_from(&hypertable)?;
    let hypertable_apply_plan = hypertable_plan.apply_plan();

    let branch = canonical_branch_spec();
    branch.validate()?;

    let tenant = canonical_tenant_spec();
    tenant.validate()?;
    let tenant_plan = TenantReconcilePlan::try_from(&tenant)?;

    let region = canonical_region_spec();
    region.validate()?;
    let region_plan = RegionReconcilePlan::try_from(&region)?;

    let survival_goal = canonical_survival_goal_spec();
    survival_goal.validate()?;
    let survival_goal_plan = SurvivalGoalReconcilePlan::new(
        &survival_goal,
        &canonical_shard_group_specs_for_survival_goal(),
        &canonical_region_specs_for_survival_goal(),
    )?;

    let backup = canonical_backup_spec();
    backup.validate()?;
    let backup_plan = BackupReconcilePlan::try_from(&backup)?;

    let vectorizer = canonical_vectorizer_spec();
    vectorizer.validate()?;

    let sidecar = canonical_sidecar_deployment_spec();
    sidecar.validate()?;

    let migration = canonical_migration_spec();
    migration.validate()?;

    let conflict_policy = canonical_conflict_policy_spec();
    conflict_policy.validate()?;

    let federation = canonical_federation_spec();
    federation.validate()?;

    let search_index = canonical_search_index_spec();
    search_index.validate()?;

    let webhook = canonical_webhook_spec();
    webhook.validate()?;

    let function = canonical_function_spec();
    function.validate()?;

    let scheduled_repack = canonical_scheduled_repack_spec();
    scheduled_repack.validate()?;

    Ok(OperatorExecutionReport {
        crds: CANONICAL_OPERATOR_CRDS,
        cluster_workers: cluster.workers,
        cluster_sidecars: cluster.sidecars.len(),
        shards: shard_group.num_shards,
        hypertable_sql_plans: hypertable_plan.sql_plans.len(),
        hypertable_apply_steps: hypertable_apply_plan.steps.len(),
        catalog_gates: V2_OPERATOR_CATALOG_GATES,
        backup_retention_days: backup.retention_days,
        vector_dimensions: vectorizer.destination.dimensions,
        function_triggers: function.triggers.len(),
        webhook_events: webhook.events.len(),
        search_columns: search_index.columns.len(),
        sidecar_replicas: sidecar.replicas,
        tenant_apply_steps: tenant_plan.steps.len(),
        region_apply_steps: region_plan.steps.len(),
        survival_goal_apply_steps: survival_goal_plan.steps.len(),
        backup_apply_steps: backup_plan.steps.len(),
    })
}

fn canonical_shard_group_specs_for_survival_goal() -> Vec<ShardGroupSpec> {
    vec![ShardGroupSpec {
        parent_table: "public.metrics".to_string(),
        distribution_column: "tenant_id".to_string(),
        num_shards: 32,
        colocation_group: Some("metrics".to_string()),
        replication_factor: 3,
        placement_policy: vec![PlacementPolicy {
            topology_key: "topology.kubernetes.io/region".to_string(),
            max_skew: 1,
            when_unsatisfiable: UnsatisfiablePlacementAction::DoNotSchedule,
        }],
    }]
}

fn canonical_region_specs_for_survival_goal() -> Vec<RegionSpec> {
    vec![
        RegionSpec {
            name: "us-east-1".to_string(),
            kubernetes_zone: "us-east-1a".to_string(),
            tablespace_name: "ts_us_east_1".to_string(),
            leader_pinned: true,
        },
        RegionSpec {
            name: "us-west-2".to_string(),
            kubernetes_zone: "us-west-2a".to_string(),
            tablespace_name: "ts_us_west_2".to_string(),
            leader_pinned: false,
        },
    ]
}

fn canonical_cluster_spec() -> CitusClusterSpec {
    CitusClusterSpec {
        topology: CitusTopology::CoordinatorWorker,
        image: "ghcr.io/ai-blaise/citus:pg18-v2".to_string(),
        workers: 3,
        coordinators: 1,
        storage_class: Some("fast-ssd".to_string()),
        timescale_enabled: true,
        extensions: vec!["citus".to_string(), "timescaledb".to_string()],
        pool: Some(PoolSpec {
            replicas: 2,
            geoip_db: Some("maxmind-city".to_string()),
        }),
        sidecars: vec![
            SidecarSpec {
                sidecar_type: SidecarType::Vectorizer,
                replicas: 1,
            },
            SidecarSpec {
                sidecar_type: SidecarType::Realtime,
                replicas: 2,
            },
            SidecarSpec {
                sidecar_type: SidecarType::Mcp,
                replicas: 1,
            },
        ],
    }
}

fn canonical_shard_group_spec() -> ShardGroupSpec {
    ShardGroupSpec {
        parent_table: "public.metrics".to_string(),
        distribution_column: "tenant_id".to_string(),
        num_shards: 32,
        colocation_group: Some("metrics".to_string()),
        replication_factor: 3,
        placement_policy: vec![PlacementPolicy {
            topology_key: "topology.kubernetes.io/zone".to_string(),
            max_skew: 1,
            when_unsatisfiable: UnsatisfiablePlacementAction::DoNotSchedule,
        }],
    }
}

fn canonical_hypertable_spec() -> HypertableSpec {
    HypertableSpec {
        table: "metrics".to_string(),
        time_column: "ts".to_string(),
        distribution_column: "tenant_id".to_string(),
        chunk_time_interval: "1 day".to_string(),
        num_shards: 32,
        compression: Some(CompressionPolicy {
            older_than: "7 days".to_string(),
            segment_by: vec!["tenant_id".to_string()],
            order_by: vec!["ts DESC".to_string()],
            bloom_filters: vec!["region".to_string()],
        }),
        retention: Some(RetentionPolicy {
            drop_after: "90 days".to_string(),
        }),
        continuous_aggregates: vec![ContinuousAggregateSpec {
            name: "metrics_hourly".to_string(),
            query: "SELECT 1".to_string(),
            refresh_start: Some("7 days".to_string()),
            refresh_end: Some("1 hour".to_string()),
            schedule: Some("15 minutes".to_string()),
            hierarchical_parent: None,
        }],
    }
}

fn canonical_branch_spec() -> BranchSpec {
    BranchSpec {
        source_cluster: "prod-us-east".to_string(),
        branch_type: BranchType::CopyOnWrite,
        storage: BranchStorageSpec {
            size: "256Gi".to_string(),
            storage_class: Some("fast-ssd".to_string()),
            snapshot_class: Some("csi-snapshot".to_string()),
        },
        suspend: true,
        retention_days: Some(7),
    }
}

fn canonical_tenant_spec() -> TenantSpec {
    TenantSpec {
        name: "tenant-a".to_string(),
        schema_name: "tenant_a".to_string(),
        quotas: TenantQuotas {
            max_connections: 64,
            max_qps: 10_000,
            max_storage_bytes: 1_099_511_627_776,
        },
        region_affinity: Some("us-east-1".to_string()),
    }
}

fn canonical_region_spec() -> RegionSpec {
    RegionSpec {
        name: "us-east-1".to_string(),
        kubernetes_zone: "us-east-1a".to_string(),
        tablespace_name: "ts_us_east_1".to_string(),
        leader_pinned: true,
    }
}

fn canonical_survival_goal_spec() -> SurvivalGoalSpec {
    SurvivalGoalSpec {
        goal: SurvivalGoalType::RegionFailure,
        regions: vec!["us-east-1".to_string(), "us-west-2".to_string()],
        min_replicas: 2,
    }
}

fn canonical_backup_spec() -> BackupSpec {
    BackupSpec {
        schedule: "0 */6 * * *".to_string(),
        retention_days: 30,
        target: BackupTarget {
            provider: BackupProvider::S3,
            bucket: "ai-blaise-citus-backups".to_string(),
            prefix: "prod/us-east-1".to_string(),
        },
        encryption: Some(BackupEncryption {
            kms_key_ref: "aws-kms-prod".to_string(),
        }),
    }
}

fn canonical_vectorizer_spec() -> VectorizerSpec {
    VectorizerSpec {
        source_table: "public.documents".to_string(),
        source_column: "body".to_string(),
        embedding_provider: EmbeddingProvider::OpenAi,
        embedding_model: "text-embedding-3-large".to_string(),
        destination: VectorDestinationSpec {
            table: "public.document_embeddings".to_string(),
            column: "embedding".to_string(),
            dimensions: 3_072,
        },
        chunking: ChunkingSpec {
            strategy: ChunkingStrategy::RecursiveText,
            max_tokens: 800,
            overlap_tokens: 80,
        },
        scheduling: VectorizerSchedulingSpec {
            mode: VectorizerScheduleMode::Interval,
            interval: Some("30 seconds".to_string()),
            max_concurrency: 8,
        },
        secret_ref: "openai-embeddings".to_string(),
    }
}

fn canonical_sidecar_deployment_spec() -> SidecarDeploymentSpec {
    SidecarDeploymentSpec {
        sidecar_type: SidecarDeploymentType::Realtime,
        replicas: 2,
        resources: ResourceRequirements {
            cpu_millis: 250,
            memory_mib: 512,
        },
        config_yaml: Some("subscriptions:\n  max_per_tenant: 1000".to_string()),
    }
}

fn canonical_migration_spec() -> MigrationSpec {
    MigrationSpec {
        migration_type: MigrationType::Pgroll,
        yaml: "operations:\n  - add_column:\n      table: users".to_string(),
        on_conflict: MigrationConflictAction::ManualReview,
    }
}

fn canonical_conflict_policy_spec() -> ConflictPolicySpec {
    ConflictPolicySpec {
        table: "public.reference_accounts".to_string(),
        class: ConflictClass::UpdateUpdate,
        resolution: ConflictResolution::LastWriteWins,
        custom_function: None,
    }
}

fn canonical_federation_spec() -> FederationSpec {
    FederationSpec {
        name: "warehouse".to_string(),
        federation_type: FederationType::Snowflake,
        connection: FederationConnection {
            secret_ref: "snowflake-warehouse".to_string(),
        },
        foreign_schema_prefix: "snowflake_".to_string(),
    }
}

fn canonical_search_index_spec() -> SearchIndexSpec {
    SearchIndexSpec {
        table: "public.documents".to_string(),
        columns: vec![
            SearchColumnSpec {
                name: "body".to_string(),
                kind: SearchColumnKind::Text,
            },
            SearchColumnSpec {
                name: "embedding".to_string(),
                kind: SearchColumnKind::Vector,
            },
        ],
        scorer: SearchScorer::Bm25Vector,
        analyzer: "english".to_string(),
        distributed: true,
    }
}

fn canonical_webhook_spec() -> WebhookSpec {
    WebhookSpec {
        table: "public.orders".to_string(),
        events: vec![WebhookEvent::Insert, WebhookEvent::Update],
        url: "https://example.com/orders".to_string(),
        headers_secret_ref: Some("orders-webhook".to_string()),
        retry_policy: WebhookRetryPolicy {
            max_attempts: 5,
            backoff: "exponential:1s:30s".to_string(),
            dead_letter_table: Some("webhook_dead_letters".to_string()),
        },
        payload_template: Some("{\"table\":\"orders\"}".to_string()),
    }
}

fn canonical_function_spec() -> FunctionSpec {
    FunctionSpec {
        name: "order-created".to_string(),
        runtime: FunctionRuntime::Deno,
        source: FunctionSource::GitRef {
            repository: "https://github.com/ai-blaise/functions".to_string(),
            reference: "main".to_string(),
            path: "orders/index.ts".to_string(),
        },
        triggers: vec![
            FunctionTrigger::Http {
                path: "/orders".to_string(),
            },
            FunctionTrigger::Event {
                table: "public.orders".to_string(),
                event: FunctionEvent::Insert,
            },
        ],
        env_secrets: vec!["orders-api-key".to_string()],
    }
}

fn canonical_scheduled_repack_spec() -> ScheduledRepackSpec {
    ScheduledRepackSpec {
        target: "public.orders".to_string(),
        schedule: "0 3 * * 0".to_string(),
        strategy: RepackStrategy::PgRepack,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn canonical_report_covers_operator_crds_and_reconcile_plan() {
        let report =
            canonical_operator_execution_report().expect("canonical operator execution report");

        assert_eq!(
            report,
            OperatorExecutionReport {
                crds: 17,
                cluster_workers: 3,
                cluster_sidecars: 3,
                shards: 32,
                hypertable_sql_plans: 5,
                hypertable_apply_steps: 8,
                catalog_gates: 13,
                backup_retention_days: 30,
                vector_dimensions: 3_072,
                function_triggers: 2,
                webhook_events: 2,
                search_columns: 2,
                sidecar_replicas: 2,
                tenant_apply_steps: 5,
                region_apply_steps: 4,
                survival_goal_apply_steps: 4,
                backup_apply_steps: 4,
            }
        );
    }
}
