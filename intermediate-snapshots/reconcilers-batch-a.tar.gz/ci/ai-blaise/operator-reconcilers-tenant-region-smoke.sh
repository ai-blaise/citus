#!/usr/bin/env bash
set -euo pipefail

# FEATURE: B2
# FEATURE: B6
# FEATURE: MR1
# FEATURE: MR2
# FEATURE: MR4
# FEATURE: MR8
# FEATURE: S10
# FEATURE: S11
# FEATURE: TO1
# FEATURE: TO2
# FEATURE: TO5

repo_root="$(git rev-parse --show-toplevel)"
cd "${repo_root}"

run_operator() {
  cargo run -q -p ai_blaise_citus_operator -- "$@"
}

canonical_tsv="$(run_operator run-canonical)"

expect_field() {
  local description="$1"
  local field="$2"
  local expected="$3"

  local header="$(printf '%s\n' "${canonical_tsv}" | head -1)"
  local data="$(printf '%s\n' "${canonical_tsv}" | tail -1)"
  local index
  index="$(printf '%s\n' "${header}" | tr '\t' '\n' \
    | awk -v needle="${field}" 'BEGIN{n=0}{n++; if($0==needle){print n; exit}}')"
  if [[ -z "${index}" ]]; then
    printf 'canonical TSV is missing column %s\n' "${field}" >&2
    printf '%s\n' "${canonical_tsv}" >&2
    exit 1
  fi
  local actual="$(printf '%s\n' "${data}" | cut -f"${index}")"
  if [[ "${actual}" != "${expected}" ]]; then
    printf 'unexpected %s for %s: expected %s, got %s\n' \
      "${field}" "${description}" "${expected}" "${actual}" >&2
    exit 1
  fi
}

# TenantReconciler: 5 steps for a tenant with region affinity
# (create schema, set quotas, set region affinity, publish pool configmap,
# register archive target).
expect_field "TenantReconciler" "tenant_apply_steps" "5"

# RegionReconciler: 4 steps for a leader-pinned region
# (ensure tablespace, register region metadata, set node affinity,
# pin CNPG leader).
expect_field "RegionReconciler" "region_apply_steps" "4"

# SurvivalGoalReconciler: 4 steps for a region-failure goal
# (record survival goal, enforce region topology spread, configure
# pgactive cross-region replication, update CNPG replication).
expect_field "SurvivalGoalReconciler" "survival_goal_apply_steps" "4"

# BackupReconciler: 4 steps for an encrypted backup
# (deploy backup sidecar, publish sidecar config, bind KMS key,
# register status probes).
expect_field "BackupReconciler" "backup_apply_steps" "4"

# Two-stage verification: cargo unit tests must pass for the 4
# reconcilers' apply plans before we accept the canonical TSV.
cargo test -q -p ai_blaise_citus_operator -- \
  reconcile::tenant:: \
  reconcile::region:: \
  reconcile::survival_goal:: \
  reconcile::backup:: \
  >/dev/null

echo "ai_blaise_citus_operator tenant+region+survival_goal+backup reconciler smoke passed"
