#!/usr/bin/env bash
set -euo pipefail

# FEATURE: TS6 TS18
#
# TS-version cohabitation matrix smoke. Iterates over the TS minor lines
# pinned in `tests/cohab-matrix/<TS_VERSION>/expected-hook-claims.tsv` and
# runs the existing single-version cohabitation smoke against each pinned
# `timescale/timescaledb:<TS_VERSION>-pg17` base image.
#
# Per-version semantics:
#   - If the Docker image tag is not yet published, log a PASS-WITH-NOTE skip
#     and continue. The matrix becomes load-bearing the moment TigerData ships
#     the image; no code change required.
#   - If the image exists, set `TIMESCALE_COHABITATION_BASE_IMAGE` to the
#     pinned tag and exec the load-bearing
#     `ci/ai-blaise/timescale-cohabitation-smoke.sh`. That script is the
#     production evidence path; the matrix is the forward-compat regression
#     net.
#
# Env knobs:
#   TS_VERSION_MATRIX            -- space-separated TS versions, defaults to
#                                   every subdir under tests/cohab-matrix/.
#   TS_VERSION_MATRIX_REQUIRED   -- space-separated TS versions whose absence
#                                   is a hard failure (defaults: 2.27).
#   REQUIRE_DOCKER               -- forwarded to the inner script.
#
# Exit codes:
#   0 -- matrix passed (every required version ran; optional versions either
#        ran or were skipped with note).
#   1 -- a required version failed or its image was unavailable.

repo_root="$(git rev-parse --show-toplevel)"
matrix_dir="${repo_root}/tests/cohab-matrix"
inner_smoke="${repo_root}/ci/ai-blaise/timescale-cohabitation-smoke.sh"
evidence_dir="${repo_root}/artifacts"
matrix_log="${evidence_dir}/ts-version-matrix-smoke.tsv"

if [[ ! -d "${matrix_dir}" ]]; then
  echo "missing matrix directory: ${matrix_dir}" >&2
  exit 1
fi

if [[ ! -x "${inner_smoke}" ]]; then
  echo "missing executable inner cohabitation smoke: ${inner_smoke}" >&2
  exit 1
fi

declare -a discovered=()
while IFS= read -r -d '' subdir; do
  version="$(basename "${subdir}")"
  discovered+=("${version}")
done < <(find "${matrix_dir}" -mindepth 1 -maxdepth 1 -type d -print0 | LC_ALL=C sort -z)

if [[ ${#discovered[@]} -eq 0 ]]; then
  echo "no TS versions discovered under ${matrix_dir}" >&2
  exit 1
fi

if [[ -n "${TS_VERSION_MATRIX:-}" ]]; then
  read -r -a versions <<<"${TS_VERSION_MATRIX}"
else
  versions=("${discovered[@]}")
fi

required_versions="${TS_VERSION_MATRIX_REQUIRED:-2.27}"

mkdir -p "${evidence_dir}"
{
  printf 'ts_version\tbase_image\tstatus\tnote\n'
} >"${matrix_log}"

overall=0
ran_any=0
for ts_version in "${versions[@]}"; do
  expected_tsv="${matrix_dir}/${ts_version}/expected-hook-claims.tsv"
  if [[ ! -s "${expected_tsv}" ]]; then
    echo "matrix entry missing expected-hook-claims.tsv: ${ts_version}" >&2
    printf '%s\t%s\t%s\t%s\n' "${ts_version}" "-" "missing-expected-tsv" "no expected-hook-claims.tsv" >>"${matrix_log}"
    overall=1
    continue
  fi

  # TimescaleDB publishes patch-pinned Docker tags (e.g. `2.27.1-pg17`), not
  # bare-minor tags. Each matrix entry pins the canonical tag in
  # `tests/cohab-matrix/<TS_VERSION>/image-tag.txt`; the file falls back to
  # `timescale/timescaledb:<TS_VERSION>-pg17` if absent so a future TS line
  # whose patch tag is unknown can still record skip-with-note.
  image_tag_file="${matrix_dir}/${ts_version}/image-tag.txt"
  if [[ -s "${image_tag_file}" ]]; then
    base_image="$(head -n 1 "${image_tag_file}" | tr -d '[:space:]')"
  else
    base_image="timescale/timescaledb:${ts_version}-pg17"
  fi
  echo "=== TS ${ts_version}: ${base_image} ==="

  if ! command -v docker >/dev/null 2>&1; then
    if [[ "${REQUIRE_DOCKER:-0}" == "1" ]]; then
      echo "docker is required for the TS-version matrix smoke" >&2
      printf '%s\t%s\t%s\t%s\n' "${ts_version}" "${base_image}" "fail" "docker unavailable but REQUIRE_DOCKER=1" >>"${matrix_log}"
      exit 1
    fi
    echo "(docker unavailable; matrix smoke records skip-with-note for TS ${ts_version})"
    printf '%s\t%s\t%s\t%s\n' "${ts_version}" "${base_image}" "skip-with-note" "docker unavailable" >>"${matrix_log}"
    continue
  fi

  if ! docker manifest inspect "${base_image}" >/dev/null 2>&1; then
    if [[ " ${required_versions} " == *" ${ts_version} "* ]]; then
      echo "TS ${ts_version} image ${base_image} not published; this version is in TS_VERSION_MATRIX_REQUIRED, failing matrix gate" >&2
      printf '%s\t%s\t%s\t%s\n' "${ts_version}" "${base_image}" "fail" "required version missing image" >>"${matrix_log}"
      overall=1
      continue
    fi
    echo "(TS ${ts_version} image ${base_image} not yet available; skipping with PASS-WITH-NOTE)"
    printf '%s\t%s\t%s\t%s\n' "${ts_version}" "${base_image}" "skip-with-note" "image tag not yet published" >>"${matrix_log}"
    continue
  fi

  echo "TS ${ts_version}: running ${inner_smoke} against ${base_image}"
  if TIMESCALE_COHABITATION_BASE_IMAGE="${base_image}" \
     TIMESCALE_COHABITATION_TAG="ai-blaise-citus-timescale-cohabitation-${ts_version//./-}:local" \
     "${inner_smoke}"; then
    container="ai-blaise-cohab-matrix-${ts_version//./-}-$$"
    # The inner smoke tore its own container down on exit. Spin up a
    # short-lived probe container against the just-built image so the matrix
    # comparator can read live `pg_extension` state. The image identity is
    # captured by the inner smoke evidence TSV.
    image_tag="ai-blaise-citus-timescale-cohabitation-${ts_version//./-}:local"
    docker run --name "${container}" \
      -e POSTGRES_PASSWORD=postgres \
      -d "${image_tag}" \
      postgres \
      -c shared_preload_libraries=timescaledb,citus \
      -c citus.cohabit_extensions=timescaledb >/dev/null
    trap 'docker rm -f "'"${container}"'" >/dev/null 2>&1 || true' EXIT
    ready=0
    for _ in $(seq 1 180); do
      if docker exec "${container}" psql -U postgres -Atqc 'SELECT 1' >/dev/null 2>&1; then
        ready=1
        break
      fi
      sleep 1
    done
    if [[ "${ready}" != "1" ]]; then
      echo "TS ${ts_version} matrix probe container did not become ready" >&2
      printf '%s\t%s\t%s\t%s\n' "${ts_version}" "${base_image}" "fail" "probe container not ready" >>"${matrix_log}"
      overall=1
      docker rm -f "${container}" >/dev/null 2>&1 || true
      continue
    fi
    docker exec "${container}" psql -U postgres -v ON_ERROR_STOP=1 -c 'CREATE EXTENSION IF NOT EXISTS citus; CREATE EXTENSION IF NOT EXISTS timescaledb;' >/dev/null
    if bash "${matrix_dir}/compare-hook-claims.sh" "${ts_version}" "${container}"; then
      printf '%s\t%s\t%s\t%s\n' "${ts_version}" "${base_image}" "pass" "cohabitation smoke and hook-claim compare matched expected" >>"${matrix_log}"
      ran_any=1
    else
      printf '%s\t%s\t%s\t%s\n' "${ts_version}" "${base_image}" "fail" "hook-claim compare diverged" >>"${matrix_log}"
      overall=1
    fi
    docker rm -f "${container}" >/dev/null 2>&1 || true
    trap - EXIT
  else
    echo "TS ${ts_version} inner cohabitation smoke failed" >&2
    printf '%s\t%s\t%s\t%s\n' "${ts_version}" "${base_image}" "fail" "inner cohabitation smoke failed" >>"${matrix_log}"
    overall=1
  fi
done

if [[ "${overall}" -ne 0 ]]; then
  echo "TS-version matrix smoke: at least one version failed; see ${matrix_log}" >&2
  exit 1
fi

if [[ "${ran_any}" -ne 1 ]]; then
  if [[ " ${required_versions} " != *" 2.27 "* ]]; then
    echo "TS-version matrix smoke: nothing ran and no required version recorded; matrix log at ${matrix_log}"
    exit 0
  fi
  echo "TS-version matrix smoke: no required version actually executed; see ${matrix_log}" >&2
  exit 1
fi

echo "TS-version matrix smoke passed; matrix log at ${matrix_log}"
