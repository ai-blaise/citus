# Extension Cohabitation

Citus normally requires its hook registrations to be first in
`shared_preload_libraries`. The ai-blaise fork now integrates the TS6 source
changes that make this guard explicitly configurable for operator-trusted
co-extensions and preserve the captured hook chain once Citus takes the outer
hook position. The matching files under `patches/` remain as reference and
upstream-rebase artifacts.

## Configuration

```conf
shared_preload_libraries = 'timescaledb,citus'
citus.cohabit_extensions = 'timescaledb'
```

`citus.cohabit_extensions` is a postmaster-level allowlist. The production
implementation currently recognizes only `timescaledb`; unsupported names do
not satisfy the trust check and Citus keeps its normal first-hook guard. The
setting should contain only extensions whose hook chain with Citus has been
explicitly covered by live cohabitation evidence.

`ci/ai-blaise/timescale-cohabitation-smoke.sh` is the production evidence path
for TS6 and TS18. It builds a real image from `timescale/timescaledb:latest-pg17`
with this Citus fork and `ai_blaise_citus` installed, starts PostgreSQL with
`shared_preload_libraries=timescaledb,citus` and
`citus.cohabit_extensions=timescaledb`, creates real `citus`, `timescaledb`,
and `ai_blaise_citus` extensions, verifies real Citus distribution metadata in
`pg_dist_partition`, and runs the bridge apply functions without defining a
Citus stub. The script records the Git SHA, image identity, and command path in
`artifacts/timescale-cohabitation-evidence.tsv`.

When the allowlist is non-empty, Citus stores any preexisting planner,
executor-start, executor-run, and EXPLAIN hooks before installing its own hooks.
Planner and executor calls continue through the stored hook when present. For
EXPLAIN, Citus delegates non-distributed statements to the stored hook and keeps
distributed statements on Citus' EXPLAIN path so worker-task output is still
produced.

The initial required cohabitation target is TimescaleDB. The current
production-ready claim is intentionally narrow: TS6 covers the trusted Citus
hook-chain source path, and TS18 covers the installable bridge-state SQL under
real Citus+TimescaleDB cohabitation. The broader TS1/TS2/TS3/TS4/TS5/TS12
distributed Timescale features remain alpha until multi-worker fanout,
rebalance, and operator reconciliation are proven end to end.

## TS-version forward-compatibility matrix

`ci/ai-blaise/ts-version-matrix-smoke.sh` is the forward-compatibility net for
TS6 and TS18. It iterates the TS minor lines pinned under `tests/cohab-matrix/`,
pulling the matching `timescale/timescaledb:<TS_VERSION>-pg17` base image and
exec'ing the existing `ci/ai-blaise/timescale-cohabitation-smoke.sh` per
iteration. Each subdir contains an `expected-hook-claims.tsv` recording which
PostgreSQL hook seams TimescaleDB is expected to claim on that minor line; the
`compare-hook-claims.sh` comparator validates the running container against
that table.

| TS version | Base image                                | Status        | Matrix entry                          |
|------------|-------------------------------------------|---------------|---------------------------------------|
| 2.27       | `timescale/timescaledb:2.27-pg17`         | load-bearing  | `tests/cohab-matrix/2.27/`            |
| 2.28       | `timescale/timescaledb:2.28-pg17`         | placeholder, skip-with-note | `tests/cohab-matrix/2.28/`  |

TimescaleDB 2.28 has not been released by TigerData at the time this matrix
lands. The matrix gate records a PASS-WITH-NOTE skip for any TS version whose
`<TS_VERSION>-pg17` image is not yet published on Docker Hub. The matrix
becomes load-bearing the moment that tag appears, with no code change required;
the new tag is picked up on the next CI run.

The matrix is forward-compatibility scaffolding, not a substitute for the
single-version cohabitation smoke. TS6 source guarantees (the trusted-coextension
allowlist and the captured-hook chain in `src/backend/distributed/shared_library_init.c`)
already capture preexisting planner, executor-start, executor-run, and EXPLAIN
hooks, so the matrix is the regression net that catches a TS minor release
reclaiming a previously-free hook (for example, `ExecutorStart_hook` was freed
in TS 2.22 when the hypercore TAM was removed and is in the `unknown` row for
TS 2.28 until live evidence lands).
