# Benchmarks

Benchmark results are recorded here per release.

These entries are benchmark targets, not production evidence, until measured
VM/container output is attached to the relevant release record and promoted in
`docs/ai-blaise/NEW_FEATURES.md`.

Initial harness targets:

- TPC-C
- sysbench OLTP
- Timescale ingest
- distributed BM25 search
- vectorizer lag
- HTAP cross-tier query latency
- failover recovery time

## TS-version coverage

Per-release benchmark records should call out the TimescaleDB minor line they
were measured against, matching the matrix entries under `tests/cohab-matrix/`.
The cohabitation smoke gate (`ci/ai-blaise/ts-version-matrix-smoke.sh`) is the
upstream source of which TS minor lines this fork has live coverage for; a
benchmark row that cites a TS version not present in the matrix is not
acceptable evidence.

| TS version | Status        | Benchmark scope                                                |
|------------|---------------|----------------------------------------------------------------|
| 2.27       | load-bearing  | All Timescale ingest, HTAP, and cohabitation benchmarks below. |
| 2.28       | placeholder   | No measured benchmarks yet; matrix records skip-with-note.     |

Benchmarks measured before TS 2.28 ships against `timescale/timescaledb:latest-pg17`
are recorded as 2.27.x rows, since `latest-pg17` resolves to the 2.27 line at
the time this matrix lands.
