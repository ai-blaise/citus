#!/usr/bin/env bash
set -euo pipefail

# FEATURE: R7
# FEATURE: C9
# FEATURE: C10
# FEATURE: C4
# FEATURE: C5
# FEATURE: M3
# FEATURE: O5
#
# Smoke check for the operator reconcilers batch-c (ScheduledRepack,
# Migration, ConflictPolicy, Sidecar). The script does three things:
#
#   1. Runs `cargo test -p ai_blaise_citus_operator` so the reconcile-plan
#      unit tests for the four new modules execute.
#   2. Runs `cargo run -p ai_blaise_citus_operator -- run-reconcile-plans-batch-c`
#      and verifies it emits the canonical TSV row covering the four
#      reconcilers.
#   3. Validates the rendered Helm RBAC template grants the *new* status
#      sub-resources we added in this PR (conflictpolicies/status,
#      migrations/status, scheduledrepacks/status, sidecars/status) and the
#      delete verbs the SidecarReconciler depends on.
#
# This is an executable smoke gate per project rule 4 (end-of-phase
# protocol) and project rule 1 (production code).

repo_root="$(git rev-parse --show-toplevel)"
cd "${repo_root}"

if ! command -v cargo >/dev/null 2>&1; then
  echo "cargo not available; cannot run operator reconcilers batch-c smoke" >&2
  exit 1
fi

echo "==> running operator reconcile-plan unit tests"
cargo test -q -p ai_blaise_citus_operator >/dev/null

echo "==> running operator run-reconcile-plans-batch-c"
plans_output="$(cargo run -q -p ai_blaise_citus_operator -- run-reconcile-plans-batch-c)"

expected_tsv=$'ai-blaise-citus-repack-weekly-orders\tpg_repack\t3\tusers-add-display-name\t6\t4\tupdate_origin_differs\tapply_remote_if_newer\t2\tai-blaise-citus-sidecar-primary-realtime\t2\t4'
if ! printf '%s\n' "${plans_output}" | grep -Fqx "${expected_tsv}"; then
  echo "operator run-reconcile-plans-batch-c did not emit expected canonical TSV row" >&2
  printf 'got:\n%s\n' "${plans_output}" >&2
  printf 'expected line:\n%s\n' "${expected_tsv}" >&2
  exit 1
fi

echo "==> verifying operator RBAC grants status sub-resources for batch-c CRDs"
rbac_template="deploy/k8s/helm/citus-overlay/templates/operator-rbac.yaml"
for required in \
  "conflictpolicies/status" \
  "migrations/status" \
  "scheduledrepacks/status" \
  "sidecars/status"; do
  if ! grep -q "${required}" "${rbac_template}"; then
    echo "operator RBAC template missing ${required} grant" >&2
    exit 1
  fi
done

echo "==> verifying operator RBAC grants Deployment + Service delete verbs"
deployments_block="$(awk '/resources: \["configmaps", "events", "services"\]/,/verbs:/' "${rbac_template}")"
apps_block="$(awk '/resources: \["deployments"\]/,/verbs:/' "${rbac_template}")"
if ! printf '%s' "${deployments_block}" | grep -q '"delete"'; then
  echo "operator RBAC core resources block must include delete verb for SidecarReconciler teardown" >&2
  exit 1
fi
if ! printf '%s' "${apps_block}" | grep -q '"delete"'; then
  echo "operator RBAC apps resources block must include delete verb for SidecarReconciler teardown" >&2
  exit 1
fi

echo "==> verifying batch-c reconcile modules carry feature markers"
for marker_pair in \
  "FEATURE: R7|operator/src/reconcile/scheduled_repack.rs" \
  "FEATURE: C9|operator/src/reconcile/migration.rs" \
  "FEATURE: C10|operator/src/reconcile/migration.rs" \
  "FEATURE: M3|operator/src/reconcile/migration.rs" \
  "FEATURE: C4|operator/src/reconcile/conflict_policy.rs" \
  "FEATURE: C5|operator/src/reconcile/conflict_policy.rs" \
  "FEATURE: O5|operator/src/reconcile/sidecar.rs"; do
  marker="${marker_pair%%|*}"
  path="${marker_pair##*|}"
  if ! grep -q "${marker}" "${path}"; then
    echo "${path} missing ${marker}" >&2
    exit 1
  fi
done

echo "operator reconcilers batch-c smoke passed"
