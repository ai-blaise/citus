// FEATURE: A8
// FEATURE: B2
// FEATURE: B6
// FEATURE: C4
// FEATURE: C5
// FEATURE: C6
// FEATURE: C7
// FEATURE: C8
// FEATURE: C9
// FEATURE: C10
// FEATURE: EF3
// FEATURE: F1
// FEATURE: M3
// FEATURE: MR1
// FEATURE: MR2
// FEATURE: MR4
// FEATURE: MR8
// FEATURE: O5
// FEATURE: R2
// FEATURE: R7
// FEATURE: S2
// FEATURE: S4
// FEATURE: S10
// FEATURE: S11
// FEATURE: Search2
// FEATURE: Search7
// FEATURE: TO1
// FEATURE: TO2
// FEATURE: TO5
// FEATURE: TS7
// FEATURE: WH1

use ai_blaise_citus_operator::{
    BackupEncryption, BackupProvider, BackupSpec, BackupTarget, BranchSpec, BranchStorageSpec,
    BranchType, ChunkingSpec, ChunkingStrategy, CitusClusterSpec, CitusTopology, CompressionPolicy,
    ConflictClass, ConflictPolicyReconcilePlan, ConflictPolicySpec, ConflictResolution,
    ContinuousAggregateSpec, EmbeddingProvider, FederationConnection, FederationSpec,
    FederationType, FunctionEvent, FunctionRuntime, FunctionSource, FunctionSpec, FunctionTrigger,
    HypertableReconcilePlan, HypertableSpec, MigrationConflictAction, MigrationReconcilePlan,
    MigrationSpec, MigrationType, PlacementPolicy, PoolSpec, RegionSpec, RepackStrategy,
    ResourceRequirements, RetentionPolicy, ScheduledRepackReconcilePlan, ScheduledRepackSpec,
    SearchColumnKind, SearchColumnSpec, SearchIndexSpec, SearchScorer, ShardGroupSpec,
    SidecarDeploymentSpec, SidecarDeploymentType, SidecarReconcilePlan, SidecarSpec, SidecarType,
    SurvivalGoalSpec, SurvivalGoalType, TenantQuotas, TenantSpec, UnsatisfiablePlacementAction,
    VectorDestinationSpec, VectorizerScheduleMode, VectorizerSchedulingSpec, VectorizerSpec,
    WebhookEvent, WebhookRetryPolicy, WebhookSpec,
};
use ai_blaise_citus_sidecar_shared::run_probe_server;
use std::env;
use std::error::Error;
use std::process;

const CANONICAL_OPERATOR_CRDS: usize = 17;
const V2_OPERATOR_CATALOG_GATES: usize = 13;

fn main() {
    let args = env::args().skip(1).collect::<Vec<_>>();
    if args.iter().any(|arg| arg == "--help" || arg == "-h") {
        print_usage();
        return;
    }
    if args == ["serve"] {
        run_server("operator", "0.0.0.0:8080");
        return;
    }

    match args.as_slice() {
        [] => run_canonical(),
        [command] if command == "run-canonical" => run_canonical(),
        [command] if command == "run-reconcile-plans-batch-c" => run_reconcile_plans_batch_c(),
        _ => {
            eprintln!("operator: unknown command");
            print_usage();
            process::exit(2);
        }
    }
}

fn run_canonical() {
    let report = canonical_operator_execution_report().unwrap_or_else(|error| {
        eprintln!("operator: canonical execution failed: {error}");
        process::exit(1);
    });

    println!(
        "crds\tcluster_workers\tcluster_sidecars\tshards\thypertable_sql_plans\thypertable_apply_steps\tcatalog_gates\tbackup_retention_days\tvector_dimensions\tfunction_triggers\twebhook_events\tsearch_columns\tsidecar_replicas\trepack_apply_steps\tmigration_apply_steps\tconflict_policy_apply_steps\tsidecar_deletion_steps"
    );
    println!(
        "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
        report.crds,
        report.cluster_workers,
        report.cluster_sidecars,
        report.shards,
        report.hypertable_sql_plans,
        report.hypertable_apply_steps,
        report.catalog_gates,
        report.backup_retention_days,
        report.vector_dimensions,
        report.function_triggers,
        report.webhook_events,
        report.search_columns,
        report.sidecar_replicas,
        report.repack_apply_steps,
        report.migration_apply_steps,
        report.conflict_policy_apply_steps,
        report.sidecar_deletion_steps,
    );
}

fn print_usage() {
    println!("usage: operator [serve|run-canonical|run-reconcile-plans-batch-c]");
}

fn run_reconcile_plans_batch_c() {
    let report = canonical_reconcile_plans_batch_c_report().unwrap_or_else(|error| {
        eprintln!("operator: reconcile plans batch-c execution failed: {error}");
        process::exit(1);
    });

    println!(
        "repack_job\trepack_strategy\trepack_apply_steps\tmigration_name\tmigration_apply_steps\tmigration_phases\tconflict_policy_class\tconflict_policy_resolution\tconflict_policy_apply_steps\tsidecar_deployment\tsidecar_replicas\tsidecar_deletion_steps"
    );
    println!(
        "{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}",
        report.repack_job,
        report.repack_strategy,
        report.repack_apply_steps,
        report.migration_name,
        report.migration_apply_steps,
        report.migration_phases,
        report.conflict_policy_class,
        report.conflict_policy_resolution,
        report.conflict_policy_apply_steps,
        report.sidecar_deployment,
        report.sidecar_replicas,
        report.sidecar_deletion_steps,
    );
}

fn run_server(component: &str, default_addr: &str) {
    if let Err(error) = run_probe_server(component, default_addr) {
        eprintln!("{component}: probe server failed: {error}");
        process::exit(1);
    }
}

#[derive(Debug, Clone, Eq, PartialEq)]
struct OperatorExecutionReport {
    crds: usize,
    cluster_workers: u32,
    cluster_sidecars: usize,
    shards: u32,
    hypertable_sql_plans: usize,
    hypertable_apply_steps: usize,
    catalog_gates: usize,
    backup_retention_days: u32,
    vector_dimensions: u32,
    function_triggers: usize,
    webhook_events: usize,
    search_columns: usize,
    sidecar_replicas: u32,
    repack_apply_steps: usize,
    migration_apply_steps: usize,
    conflict_policy_apply_steps: usize,
    sidecar_deletion_steps: usize,
}

#[derive(Debug, Clone, Eq, PartialEq)]
struct ReconcilePlansBatchCReport {
    repack_job: String,
    repack_strategy: String,
    repack_apply_steps: usize,
    migration_name: String,
    migration_apply_steps: usize,
    migration_phases: usize,
    conflict_policy_class: String,
    conflict_policy_resolution: String,
    conflict_policy_apply_steps: usize,
    sidecar_deployment: String,
    sidecar_replicas: u32,
    sidecar_deletion_steps: usize,
}

fn canonical_operator_execution_report() -> Result<OperatorExecutionReport, Box<dyn Error>> {
    let cluster = canonical_cluster_spec();
    cluster.validate()?;

    let shard_group = canonical_shard_group_spec();
    shard_group.validate()?;

    let hypertable = canonical_hypertable_spec();
    hypertable.validate()?;
    let hypertable_plan = HypertableReconcilePlan::try_from(&hypertable)?;
    let hypertable_apply_plan = hypertable_plan.apply_plan();

    let branch = canonical_branch_spec();
    branch.validate()?;

    let tenant = canonical_tenant_spec();
    tenant.validate()?;

    let region = canonical_region_spec();
    region.validate()?;

    let survival_goal = canonical_survival_goal_spec();
    survival_goal.validate()?;

    let backup = canonical_backup_spec();
    backup.validate()?;

    let vectorizer = canonical_vectorizer_spec();
    vectorizer.validate()?;

    let sidecar = canonical_sidecar_deployment_spec();
    sidecar.validate()?;

    let migration = canonical_migration_spec();
    migration.validate()?;

    let conflict_policy = canonical_conflict_policy_spec();
    conflict_policy.validate()?;

    let federation = canonical_federation_spec();
    federation.validate()?;

    let search_index = canonical_search_index_spec();
    search_index.validate()?;

    let webhook = canonical_webhook_spec();
    webhook.validate()?;

    let function = canonical_function_spec();
    function.validate()?;

    let scheduled_repack = canonical_scheduled_repack_spec();
    scheduled_repack.validate()?;

    let repack_plan = ScheduledRepackReconcilePlan::from_spec(
        "weekly-orders",
        "http://citus-sidecar-repack:8080/",
        &scheduled_repack,
    )?;
    let repack_apply_plan = repack_plan.apply_plan();

    let migration_plan =
        MigrationReconcilePlan::from_spec("users-add-display-name", &migration)?;
    let migration_apply_plan = migration_plan.apply_plan();

    let conflict_policy_plan =
        ConflictPolicyReconcilePlan::from_spec("accounts-lww", &conflict_policy)?;
    let conflict_policy_apply_plan = conflict_policy_plan.apply_plan();

    let sidecar_reconcile_plan = SidecarReconcilePlan::from_spec("primary", &sidecar)?;
    let sidecar_deletion_plan = sidecar_reconcile_plan.deletion_plan();

    Ok(OperatorExecutionReport {
        crds: CANONICAL_OPERATOR_CRDS,
        cluster_workers: cluster.workers,
        cluster_sidecars: cluster.sidecars.len(),
        shards: shard_group.num_shards,
        hypertable_sql_plans: hypertable_plan.sql_plans.len(),
        hypertable_apply_steps: hypertable_apply_plan.steps.len(),
        catalog_gates: V2_OPERATOR_CATALOG_GATES,
        backup_retention_days: backup.retention_days,
        vector_dimensions: vectorizer.destination.dimensions,
        function_triggers: function.triggers.len(),
        webhook_events: webhook.events.len(),
        search_columns: search_index.columns.len(),
        sidecar_replicas: sidecar.replicas,
        repack_apply_steps: repack_apply_plan.steps.len(),
        migration_apply_steps: migration_apply_plan.steps.len(),
        conflict_policy_apply_steps: conflict_policy_apply_plan.steps.len(),
        sidecar_deletion_steps: sidecar_deletion_plan.steps.len(),
    })
}

fn canonical_reconcile_plans_batch_c_report(
) -> Result<ReconcilePlansBatchCReport, Box<dyn Error>> {
    let scheduled_repack = canonical_scheduled_repack_spec();
    let repack_plan = ScheduledRepackReconcilePlan::from_spec(
        "weekly-orders",
        "http://citus-sidecar-repack:8080/",
        &scheduled_repack,
    )?;
    let repack_apply_plan = repack_plan.apply_plan();

    let migration = canonical_migration_spec();
    let migration_plan =
        MigrationReconcilePlan::from_spec("users-add-display-name", &migration)?;
    let migration_apply_plan = migration_plan.apply_plan();

    let conflict_policy = canonical_conflict_policy_spec();
    let conflict_policy_plan =
        ConflictPolicyReconcilePlan::from_spec("accounts-lww", &conflict_policy)?;
    let conflict_policy_apply_plan = conflict_policy_plan.apply_plan();

    let sidecar = canonical_sidecar_deployment_spec();
    let sidecar_plan = SidecarReconcilePlan::from_spec("primary", &sidecar)?;
    let sidecar_deletion_plan = sidecar_plan.deletion_plan();

    Ok(ReconcilePlansBatchCReport {
        repack_job: repack_plan.job_name.clone(),
        repack_strategy: repack_plan.strategy_str().to_string(),
        repack_apply_steps: repack_apply_plan.steps.len(),
        migration_name: migration_plan.migration_name.clone(),
        migration_apply_steps: migration_apply_plan.steps.len(),
        migration_phases: migration_plan.phases.len(),
        conflict_policy_class: conflict_policy_plan.class_str().to_string(),
        conflict_policy_resolution: conflict_policy_plan.resolution_str().to_string(),
        conflict_policy_apply_steps: conflict_policy_apply_plan.steps.len(),
        sidecar_deployment: sidecar_plan.deployment_name.clone(),
        sidecar_replicas: sidecar_plan.replicas,
        sidecar_deletion_steps: sidecar_deletion_plan.steps.len(),
    })
}

fn canonical_cluster_spec() -> CitusClusterSpec {
    CitusClusterSpec {
        topology: CitusTopology::CoordinatorWorker,
        image: "ghcr.io/ai-blaise/citus:pg18-v2".to_string(),
        workers: 3,
        coordinators: 1,
        storage_class: Some("fast-ssd".to_string()),
        timescale_enabled: true,
        extensions: vec!["citus".to_string(), "timescaledb".to_string()],
        pool: Some(PoolSpec {
            replicas: 2,
            geoip_db: Some("maxmind-city".to_string()),
        }),
        sidecars: vec![
            SidecarSpec {
                sidecar_type: SidecarType::Vectorizer,
                replicas: 1,
            },
            SidecarSpec {
                sidecar_type: SidecarType::Realtime,
                replicas: 2,
            },
            SidecarSpec {
                sidecar_type: SidecarType::Mcp,
                replicas: 1,
            },
        ],
    }
}

fn canonical_shard_group_spec() -> ShardGroupSpec {
    ShardGroupSpec {
        parent_table: "public.metrics".to_string(),
        distribution_column: "tenant_id".to_string(),
        num_shards: 32,
        colocation_group: Some("metrics".to_string()),
        replication_factor: 3,
        placement_policy: vec![PlacementPolicy {
            topology_key: "topology.kubernetes.io/zone".to_string(),
            max_skew: 1,
            when_unsatisfiable: UnsatisfiablePlacementAction::DoNotSchedule,
        }],
    }
}

fn canonical_hypertable_spec() -> HypertableSpec {
    HypertableSpec {
        table: "metrics".to_string(),
        time_column: "ts".to_string(),
        distribution_column: "tenant_id".to_string(),
        chunk_time_interval: "1 day".to_string(),
        num_shards: 32,
        compression: Some(CompressionPolicy {
            older_than: "7 days".to_string(),
            segment_by: vec!["tenant_id".to_string()],
            order_by: vec!["ts DESC".to_string()],
            bloom_filters: vec!["region".to_string()],
        }),
        retention: Some(RetentionPolicy {
            drop_after: "90 days".to_string(),
        }),
        continuous_aggregates: vec![ContinuousAggregateSpec {
            name: "metrics_hourly".to_string(),
            query: "SELECT 1".to_string(),
            refresh_start: Some("7 days".to_string()),
            refresh_end: Some("1 hour".to_string()),
            schedule: Some("15 minutes".to_string()),
            hierarchical_parent: None,
        }],
    }
}

fn canonical_branch_spec() -> BranchSpec {
    BranchSpec {
        source_cluster: "prod-us-east".to_string(),
        branch_type: BranchType::CopyOnWrite,
        storage: BranchStorageSpec {
            size: "256Gi".to_string(),
            storage_class: Some("fast-ssd".to_string()),
            snapshot_class: Some("csi-snapshot".to_string()),
        },
        suspend: true,
        retention_days: Some(7),
    }
}

fn canonical_tenant_spec() -> TenantSpec {
    TenantSpec {
        name: "tenant-a".to_string(),
        schema_name: "tenant_a".to_string(),
        quotas: TenantQuotas {
            max_connections: 64,
            max_qps: 10_000,
            max_storage_bytes: 1_099_511_627_776,
        },
        region_affinity: Some("us-east-1".to_string()),
    }
}

fn canonical_region_spec() -> RegionSpec {
    RegionSpec {
        name: "us-east-1".to_string(),
        kubernetes_zone: "us-east-1a".to_string(),
        tablespace_name: "ts_us_east_1".to_string(),
        leader_pinned: true,
    }
}

fn canonical_survival_goal_spec() -> SurvivalGoalSpec {
    SurvivalGoalSpec {
        goal: SurvivalGoalType::RegionFailure,
        regions: vec!["us-east-1".to_string(), "us-west-2".to_string()],
        min_replicas: 2,
    }
}

fn canonical_backup_spec() -> BackupSpec {
    BackupSpec {
        schedule: "0 */6 * * *".to_string(),
        retention_days: 30,
        target: BackupTarget {
            provider: BackupProvider::S3,
            bucket: "ai-blaise-citus-backups".to_string(),
            prefix: "prod/us-east-1".to_string(),
        },
        encryption: Some(BackupEncryption {
            kms_key_ref: "aws-kms-prod".to_string(),
        }),
    }
}

fn canonical_vectorizer_spec() -> VectorizerSpec {
    VectorizerSpec {
        source_table: "public.documents".to_string(),
        source_column: "body".to_string(),
        embedding_provider: EmbeddingProvider::OpenAi,
        embedding_model: "text-embedding-3-large".to_string(),
        destination: VectorDestinationSpec {
            table: "public.document_embeddings".to_string(),
            column: "embedding".to_string(),
            dimensions: 3_072,
        },
        chunking: ChunkingSpec {
            strategy: ChunkingStrategy::RecursiveText,
            max_tokens: 800,
            overlap_tokens: 80,
        },
        scheduling: VectorizerSchedulingSpec {
            mode: VectorizerScheduleMode::Interval,
            interval: Some("30 seconds".to_string()),
            max_concurrency: 8,
        },
        secret_ref: "openai-embeddings".to_string(),
    }
}

fn canonical_sidecar_deployment_spec() -> SidecarDeploymentSpec {
    SidecarDeploymentSpec {
        sidecar_type: SidecarDeploymentType::Realtime,
        replicas: 2,
        resources: ResourceRequirements {
            cpu_millis: 250,
            memory_mib: 512,
        },
        config_yaml: Some("subscriptions:\n  max_per_tenant: 1000".to_string()),
    }
}

fn canonical_migration_spec() -> MigrationSpec {
    MigrationSpec {
        migration_type: MigrationType::Pgroll,
        yaml: "operations:\n  - add_column:\n      table: users".to_string(),
        on_conflict: MigrationConflictAction::ManualReview,
    }
}

fn canonical_conflict_policy_spec() -> ConflictPolicySpec {
    ConflictPolicySpec {
        table: "public.reference_accounts".to_string(),
        class: ConflictClass::UpdateUpdate,
        resolution: ConflictResolution::LastWriteWins,
        custom_function: None,
    }
}

fn canonical_federation_spec() -> FederationSpec {
    FederationSpec {
        name: "warehouse".to_string(),
        federation_type: FederationType::Snowflake,
        connection: FederationConnection {
            secret_ref: "snowflake-warehouse".to_string(),
        },
        foreign_schema_prefix: "snowflake_".to_string(),
    }
}

fn canonical_search_index_spec() -> SearchIndexSpec {
    SearchIndexSpec {
        table: "public.documents".to_string(),
        columns: vec![
            SearchColumnSpec {
                name: "body".to_string(),
                kind: SearchColumnKind::Text,
            },
            SearchColumnSpec {
                name: "embedding".to_string(),
                kind: SearchColumnKind::Vector,
            },
        ],
        scorer: SearchScorer::Bm25Vector,
        analyzer: "english".to_string(),
        distributed: true,
    }
}

fn canonical_webhook_spec() -> WebhookSpec {
    WebhookSpec {
        table: "public.orders".to_string(),
        events: vec![WebhookEvent::Insert, WebhookEvent::Update],
        url: "https://example.com/orders".to_string(),
        headers_secret_ref: Some("orders-webhook".to_string()),
        retry_policy: WebhookRetryPolicy {
            max_attempts: 5,
            backoff: "exponential:1s:30s".to_string(),
            dead_letter_table: Some("webhook_dead_letters".to_string()),
        },
        payload_template: Some("{\"table\":\"orders\"}".to_string()),
    }
}

fn canonical_function_spec() -> FunctionSpec {
    FunctionSpec {
        name: "order-created".to_string(),
        runtime: FunctionRuntime::Deno,
        source: FunctionSource::GitRef {
            repository: "https://github.com/ai-blaise/functions".to_string(),
            reference: "main".to_string(),
            path: "orders/index.ts".to_string(),
        },
        triggers: vec![
            FunctionTrigger::Http {
                path: "/orders".to_string(),
            },
            FunctionTrigger::Event {
                table: "public.orders".to_string(),
                event: FunctionEvent::Insert,
            },
        ],
        env_secrets: vec!["orders-api-key".to_string()],
    }
}

fn canonical_scheduled_repack_spec() -> ScheduledRepackSpec {
    ScheduledRepackSpec {
        target: "public.orders".to_string(),
        schedule: "0 3 * * 0".to_string(),
        strategy: RepackStrategy::PgRepack,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn canonical_report_covers_operator_crds_and_reconcile_plan() {
        let report =
            canonical_operator_execution_report().expect("canonical operator execution report");

        assert_eq!(
            report,
            OperatorExecutionReport {
                crds: 17,
                cluster_workers: 3,
                cluster_sidecars: 3,
                shards: 32,
                hypertable_sql_plans: 5,
                hypertable_apply_steps: 8,
                catalog_gates: 13,
                backup_retention_days: 30,
                vector_dimensions: 3_072,
                function_triggers: 2,
                webhook_events: 2,
                search_columns: 2,
                sidecar_replicas: 2,
                repack_apply_steps: 3,
                migration_apply_steps: 6,
                conflict_policy_apply_steps: 2,
                sidecar_deletion_steps: 4,
            }
        );
    }

    #[test]
    fn canonical_reconcile_plans_batch_c_report_covers_four_reconcilers() {
        let report = canonical_reconcile_plans_batch_c_report()
            .expect("canonical reconcile plans batch-c report");

        assert_eq!(
            report,
            ReconcilePlansBatchCReport {
                repack_job: "ai-blaise-citus-repack-weekly-orders".to_string(),
                repack_strategy: "pg_repack".to_string(),
                repack_apply_steps: 3,
                migration_name: "users-add-display-name".to_string(),
                migration_apply_steps: 6,
                migration_phases: 4,
                conflict_policy_class: "update_origin_differs".to_string(),
                conflict_policy_resolution: "apply_remote_if_newer".to_string(),
                conflict_policy_apply_steps: 2,
                sidecar_deployment: "ai-blaise-citus-sidecar-primary-realtime".to_string(),
                sidecar_replicas: 2,
                sidecar_deletion_steps: 4,
            }
        );
    }
}
