// FEATURE: R7

use std::error::Error;
use std::fmt;

use crate::crds::scheduled_repack::{
    RepackStrategy, ScheduledRepackSpec, ScheduledRepackSpecError,
};

/// HTTP path exposed by the repack sidecar to trigger an online repack.
/// Operators register a pg_cron job that posts to this endpoint with the
/// reconcile plan's payload so the repack action survives operator restarts
/// and is observable via sidecar metrics.
pub const REPACK_SIDECAR_REPACK_PATH: &str = "/repack";

/// Schema-qualified pg_cron schedule helper used by the reconcile plan. We
/// always go through `companion_internal.scheduled_repack_register` so that
/// pg_cron job ownership stays in the `ai_blaise_citus` extension.
pub const COMPANION_REGISTER_FUNCTION: &str = "companion_internal.scheduled_repack_register";

/// Schema-qualified pg_cron unregister helper invoked when the CR is removed.
pub const COMPANION_UNREGISTER_FUNCTION: &str = "companion_internal.scheduled_repack_unregister";

/// Resolved reconcile plan derived from a `ScheduledRepackSpec`. The plan
/// captures everything required to register a pg_cron job that calls the
/// repack sidecar's `POST /repack` endpoint, plus the rollback SQL needed to
/// unregister the job when the CR is deleted.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct ScheduledRepackReconcilePlan {
    pub job_name: String,
    pub target: String,
    pub schedule: String,
    pub strategy: RepackStrategy,
    pub sidecar_endpoint: String,
}

impl ScheduledRepackReconcilePlan {
    /// Build a reconcile plan from the named ScheduledRepack CR. The
    /// `repack_name` is the `metadata.name` of the owning CRD so that the
    /// derived pg_cron job stays deterministic across reconciliation passes.
    pub fn from_spec(
        repack_name: &str,
        sidecar_base_url: &str,
        spec: &ScheduledRepackSpec,
    ) -> Result<Self, ScheduledRepackReconcileError> {
        let trimmed_name = repack_name.trim();
        if trimmed_name.is_empty() {
            return Err(ScheduledRepackReconcileError::MissingRepackName);
        }
        let trimmed_base = sidecar_base_url.trim().trim_end_matches('/');
        if trimmed_base.is_empty() {
            return Err(ScheduledRepackReconcileError::MissingSidecarBaseUrl);
        }
        spec.validate()?;

        Ok(Self {
            job_name: format!("ai-blaise-citus-repack-{trimmed_name}"),
            target: spec.target.clone(),
            schedule: spec.schedule.clone(),
            strategy: spec.strategy,
            sidecar_endpoint: format!("{trimmed_base}{REPACK_SIDECAR_REPACK_PATH}"),
        })
    }

    /// Strategy as the value the sidecar accepts on the `POST /repack`
    /// payload. The strings stay stable across reconciliations because the
    /// sidecar parses them.
    pub fn strategy_str(&self) -> &'static str {
        match self.strategy {
            RepackStrategy::PgRepack => "pg_repack",
            RepackStrategy::RepackConcurrentlyPg19 => "repack_concurrently_pg19",
        }
    }

    /// JSON body posted by the registered pg_cron job to the repack sidecar.
    /// This is the canonical contract the sidecar exposes; emitting it from
    /// the reconciler keeps the operator and the sidecar in lockstep.
    pub fn sidecar_payload_json(&self) -> String {
        format!(
            "{{\"target\":\"{target}\",\"strategy\":\"{strategy}\",\"job\":\"{job}\"}}",
            target = escape_json(&self.target),
            strategy = self.strategy_str(),
            job = escape_json(&self.job_name),
        )
    }

    /// Render the SQL apply plan that registers the pg_cron job and records a
    /// matching row in `companion_scheduled_repacks` for status reporting.
    pub fn apply_plan(&self) -> ScheduledRepackApplyPlan {
        let steps = vec![
            ScheduledRepackApplyStep::new(
                "ensure_ai_blaise_citus_extension",
                "CREATE EXTENSION IF NOT EXISTS ai_blaise_citus;",
                true,
            ),
            ScheduledRepackApplyStep::new(
                "ensure_pg_cron_extension",
                "CREATE EXTENSION IF NOT EXISTS pg_cron;",
                true,
            ),
            ScheduledRepackApplyStep::new(
                "register_scheduled_repack",
                register_scheduled_repack_sql(self),
                true,
            ),
        ];

        ScheduledRepackApplyPlan { steps }
    }

    /// Render the apply-plan SQL script directly.
    pub fn apply_sql_script(&self) -> String {
        self.apply_plan().sql_script()
    }

    /// Render the SQL teardown plan that unregisters the pg_cron job when the
    /// CR is removed.
    pub fn teardown_sql(&self) -> String {
        format!(
            "SELECT {function}({job_name});",
            function = COMPANION_UNREGISTER_FUNCTION,
            job_name = sql_literal(&self.job_name),
        )
    }

    /// SQL that reads the bloat estimate for the repack target. Reconcilers
    /// use this to populate the CR's `.status.currentBloatEstimate` field.
    /// `companion.bloat_estimate` is preferred when present; we fall back to
    /// `pg_stat_user_tables.n_dead_tup` so the status field is always
    /// populated even without the companion runtime.
    pub fn bloat_estimate_sql(&self) -> String {
        format!(
            r#"SELECT coalesce(
    (SELECT bloat_bytes FROM companion.bloat_estimate({table})),
    (SELECT n_dead_tup FROM pg_catalog.pg_stat_user_tables
        WHERE schemaname || '.' || relname = {target_text})
) AS bloat_estimate;"#,
            table = sql_literal(&self.target),
            target_text = sql_literal(&self.target),
        )
    }
}

/// SQL apply step generated by the scheduled-repack reconciler.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct ScheduledRepackApplyStep {
    pub name: String,
    pub sql: String,
    pub idempotent: bool,
}

impl ScheduledRepackApplyStep {
    fn new(name: impl Into<String>, sql: impl Into<String>, idempotent: bool) -> Self {
        Self {
            name: name.into(),
            sql: sql.into(),
            idempotent,
        }
    }
}

/// Apply plan composed of `ScheduledRepackApplyStep`s in execution order.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct ScheduledRepackApplyPlan {
    pub steps: Vec<ScheduledRepackApplyStep>,
}

impl ScheduledRepackApplyPlan {
    pub fn sql_script(&self) -> String {
        self.steps
            .iter()
            .map(|step| step.sql.trim_end())
            .collect::<Vec<_>>()
            .join("\n")
    }
}

fn register_scheduled_repack_sql(plan: &ScheduledRepackReconcilePlan) -> String {
    format!(
        "SELECT {function}({job}, {schedule}, {target}, {strategy}, {endpoint});",
        function = COMPANION_REGISTER_FUNCTION,
        job = sql_literal(&plan.job_name),
        schedule = sql_literal(&plan.schedule),
        target = sql_literal(&plan.target),
        strategy = sql_literal(plan.strategy_str()),
        endpoint = sql_literal(&plan.sidecar_endpoint),
    )
}

fn sql_literal(value: &str) -> String {
    format!("'{}'", value.replace('\'', "''"))
}

fn escape_json(value: &str) -> String {
    let mut escaped = String::with_capacity(value.len());
    for character in value.chars() {
        match character {
            '"' => escaped.push_str("\\\""),
            '\\' => escaped.push_str("\\\\"),
            '\n' => escaped.push_str("\\n"),
            '\r' => escaped.push_str("\\r"),
            '\t' => escaped.push_str("\\t"),
            character if (character as u32) < 0x20 => {
                escaped.push_str(&format!("\\u{:04x}", character as u32));
            }
            character => escaped.push(character),
        }
    }
    escaped
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub enum ScheduledRepackReconcileError {
    InvalidSpec(ScheduledRepackSpecError),
    MissingRepackName,
    MissingSidecarBaseUrl,
}

impl fmt::Display for ScheduledRepackReconcileError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidSpec(error) => write!(formatter, "{error}"),
            Self::MissingRepackName => write!(formatter, "repack_name must not be empty"),
            Self::MissingSidecarBaseUrl => {
                write!(formatter, "sidecar_base_url must not be empty")
            }
        }
    }
}

impl Error for ScheduledRepackReconcileError {}

impl From<ScheduledRepackSpecError> for ScheduledRepackReconcileError {
    fn from(error: ScheduledRepackSpecError) -> Self {
        Self::InvalidSpec(error)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pg_repack_plan_renders_register_payload_and_sql() {
        let spec = ScheduledRepackSpec {
            target: "public.orders".to_string(),
            schedule: "0 3 * * 0".to_string(),
            strategy: RepackStrategy::PgRepack,
        };

        let plan = ScheduledRepackReconcilePlan::from_spec(
            "weekly-orders",
            "http://citus-sidecar-repack:8080/",
            &spec,
        )
        .expect("valid plan");

        assert_eq!(plan.job_name, "ai-blaise-citus-repack-weekly-orders");
        assert_eq!(plan.strategy_str(), "pg_repack");
        assert_eq!(
            plan.sidecar_endpoint,
            "http://citus-sidecar-repack:8080/repack"
        );

        let payload = plan.sidecar_payload_json();
        assert!(payload.contains("\"target\":\"public.orders\""));
        assert!(payload.contains("\"strategy\":\"pg_repack\""));
        assert!(payload.contains("\"job\":\"ai-blaise-citus-repack-weekly-orders\""));

        let apply_plan = plan.apply_plan();
        assert_eq!(apply_plan.steps.len(), 3);
        assert_eq!(apply_plan.steps[0].name, "ensure_ai_blaise_citus_extension");
        assert_eq!(apply_plan.steps[1].name, "ensure_pg_cron_extension");
        assert_eq!(apply_plan.steps[2].name, "register_scheduled_repack");
        assert!(apply_plan.steps[2]
            .sql
            .contains("companion_internal.scheduled_repack_register"));
        assert!(apply_plan.steps[2]
            .sql
            .contains("'ai-blaise-citus-repack-weekly-orders'"));
        assert!(apply_plan.steps[2].sql.contains("'public.orders'"));
        assert!(apply_plan.steps[2].sql.contains("'pg_repack'"));
        assert!(apply_plan.steps[2]
            .sql
            .contains("'http://citus-sidecar-repack:8080/repack'"));

        let teardown = plan.teardown_sql();
        assert!(teardown.contains("companion_internal.scheduled_repack_unregister"));
        assert!(teardown.contains("'ai-blaise-citus-repack-weekly-orders'"));

        let bloat = plan.bloat_estimate_sql();
        assert!(bloat.contains("companion.bloat_estimate('public.orders')"));
        assert!(bloat.contains("pg_stat_user_tables"));
    }

    #[test]
    fn pg19_strategy_renders_repack_concurrently() {
        let spec = ScheduledRepackSpec {
            target: "public.events".to_string(),
            schedule: "0 4 * * *".to_string(),
            strategy: RepackStrategy::RepackConcurrentlyPg19,
        };

        let plan = ScheduledRepackReconcilePlan::from_spec(
            "events-nightly",
            "http://citus-sidecar-repack:8080",
            &spec,
        )
        .expect("valid plan");

        assert_eq!(plan.strategy_str(), "repack_concurrently_pg19");
        let script = plan.apply_sql_script();
        assert!(script.contains("'repack_concurrently_pg19'"));
        assert!(script.contains("'http://citus-sidecar-repack:8080/repack'"));
    }

    #[test]
    fn empty_repack_name_is_rejected() {
        let spec = ScheduledRepackSpec {
            target: "public.orders".to_string(),
            schedule: "0 3 * * 0".to_string(),
            strategy: RepackStrategy::PgRepack,
        };

        assert_eq!(
            ScheduledRepackReconcilePlan::from_spec("  ", "http://repack/", &spec),
            Err(ScheduledRepackReconcileError::MissingRepackName)
        );
    }

    #[test]
    fn empty_sidecar_base_url_is_rejected() {
        let spec = ScheduledRepackSpec {
            target: "public.orders".to_string(),
            schedule: "0 3 * * 0".to_string(),
            strategy: RepackStrategy::PgRepack,
        };

        assert_eq!(
            ScheduledRepackReconcilePlan::from_spec("weekly", "  ", &spec),
            Err(ScheduledRepackReconcileError::MissingSidecarBaseUrl)
        );
    }

    #[test]
    fn invalid_spec_propagates_validation_error() {
        let spec = ScheduledRepackSpec {
            target: String::new(),
            schedule: "0 3 * * 0".to_string(),
            strategy: RepackStrategy::PgRepack,
        };

        assert_eq!(
            ScheduledRepackReconcilePlan::from_spec("weekly", "http://repack/", &spec),
            Err(ScheduledRepackReconcileError::InvalidSpec(
                ScheduledRepackSpecError::MissingRequiredField("target")
            ))
        );
    }

    #[test]
    fn quoted_target_is_escaped_for_sql_and_json() {
        let spec = ScheduledRepackSpec {
            target: "public.\"weird'name\"".to_string(),
            schedule: "@daily".to_string(),
            strategy: RepackStrategy::PgRepack,
        };

        let plan = ScheduledRepackReconcilePlan::from_spec(
            "edge",
            "http://citus-sidecar-repack:8080/",
            &spec,
        )
        .expect("valid plan");
        let script = plan.apply_sql_script();
        assert!(script.contains("'public.\"weird''name\"'"));

        let payload = plan.sidecar_payload_json();
        assert!(payload.contains("\"target\":\"public.\\\"weird'name\\\"\""));
    }
}
