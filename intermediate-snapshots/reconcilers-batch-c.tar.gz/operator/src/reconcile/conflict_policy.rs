// FEATURE: C4
// FEATURE: C5

use std::error::Error;
use std::fmt;

use crate::crds::conflict_policy::{
    ConflictClass, ConflictPolicySpec, ConflictPolicySpecError, ConflictResolution,
};

/// Schema-qualified helper used by the reconciler to register a conflict
/// policy with the companion replication-conflict runtime. The runtime stores
/// the row in `companion_replication_conflict_policies` and wires the trigger
/// callback used during logical-replication apply.
pub const COMPANION_REGISTER_POLICY_FUNCTION: &str =
    "companion_internal.replication_conflict_policy_register";

/// Schema-qualified helper invoked when the CR is deleted.
pub const COMPANION_UNREGISTER_POLICY_FUNCTION: &str =
    "companion_internal.replication_conflict_policy_unregister";

/// Schema-qualified helper used to validate that a custom resolution function
/// exists in `pg_proc` and has the expected `(jsonb, jsonb) RETURNS jsonb`
/// signature.
pub const COMPANION_VALIDATE_CUSTOM_FUNCTION: &str =
    "companion_internal.replication_conflict_validate_function";

/// Schema-qualified view used to populate the CR's status with conflict
/// counts per class and the last-conflict timestamp.
pub const COMPANION_STATUS_VIEW: &str = "companion.replication_conflict_status";

/// Resolved reconcile plan derived from a `ConflictPolicySpec`. The plan
/// captures everything required to register the policy with the companion
/// replication-conflict runtime, including optional validation of a custom
/// resolution function.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct ConflictPolicyReconcilePlan {
    pub policy_name: String,
    pub table: String,
    pub class: ConflictClass,
    pub resolution: ConflictResolution,
    pub custom_function: Option<String>,
}

impl ConflictPolicyReconcilePlan {
    /// Build a reconcile plan from the named ConflictPolicy CR. `policy_name`
    /// is the `metadata.name` of the owning CRD so the registered policy key
    /// is deterministic across reconciliation passes.
    pub fn from_spec(
        policy_name: &str,
        spec: &ConflictPolicySpec,
    ) -> Result<Self, ConflictPolicyReconcileError> {
        let trimmed_name = policy_name.trim();
        if trimmed_name.is_empty() {
            return Err(ConflictPolicyReconcileError::MissingPolicyName);
        }
        spec.validate()?;

        Ok(Self {
            policy_name: trimmed_name.to_string(),
            table: spec.table.clone(),
            class: spec.class,
            resolution: spec.resolution,
            custom_function: spec.custom_function.clone(),
        })
    }

    /// Conflict class string accepted by the companion runtime. Mirrors the
    /// Spock seven-class taxonomy used at logical-replication apply time.
    pub fn class_str(&self) -> &'static str {
        match self.class {
            ConflictClass::InsertInsert => "insert_exists",
            ConflictClass::InsertUpdate => "update_missing",
            ConflictClass::UpdateUpdate => "update_origin_differs",
            ConflictClass::UpdateDelete => "update_pkey_exists",
            ConflictClass::DeleteUpdate => "delete_origin_differs",
            ConflictClass::DeleteDelete => "delete_missing",
            ConflictClass::Constraint => "update_concurrent",
        }
    }

    /// Resolution string accepted by the companion runtime.
    pub fn resolution_str(&self) -> &'static str {
        match self.resolution {
            ConflictResolution::LastWriteWins => "apply_remote_if_newer",
            ConflictResolution::OriginWins => "apply_remote",
            ConflictResolution::TargetWins => "keep_local",
            ConflictResolution::Skip => "keep_local",
            ConflictResolution::Error => "error",
            ConflictResolution::CustomFunction => "merge_function",
        }
    }

    /// Render the SQL apply plan that records the policy in the companion
    /// runtime. When a custom function is configured, the plan first
    /// validates that the function exists and has the correct signature.
    pub fn apply_plan(&self) -> ConflictPolicyApplyPlan {
        let mut steps = vec![ConflictPolicyApplyStep::new(
            "ensure_ai_blaise_citus_extension",
            "CREATE EXTENSION IF NOT EXISTS ai_blaise_citus;",
            true,
        )];

        if let Some(custom_function) = &self.custom_function {
            steps.push(ConflictPolicyApplyStep::new(
                "validate_custom_function",
                validate_custom_function_sql(custom_function),
                true,
            ));
        }

        steps.push(ConflictPolicyApplyStep::new(
            "register_conflict_policy",
            register_policy_sql(self),
            true,
        ));

        ConflictPolicyApplyPlan { steps }
    }

    /// Render the apply-plan SQL script directly.
    pub fn apply_sql_script(&self) -> String {
        self.apply_plan().sql_script()
    }

    /// Render the teardown SQL run when the CR is deleted. We unregister the
    /// policy so the logical-replication apply path falls back to the
    /// runtime's default conflict behaviour rather than continuing to fire a
    /// stale callback.
    pub fn teardown_sql(&self) -> String {
        format!(
            "SELECT {function}({name});",
            function = COMPANION_UNREGISTER_POLICY_FUNCTION,
            name = sql_literal(&self.policy_name),
        )
    }

    /// SQL that reads conflict counts and the last-conflict timestamp from
    /// the companion runtime. Reconcilers use this to populate the CR's
    /// status fields.
    pub fn status_sql(&self) -> String {
        format!(
            "SELECT class, conflict_count, last_conflict_at FROM {view} WHERE policy = {name};",
            view = COMPANION_STATUS_VIEW,
            name = sql_literal(&self.policy_name),
        )
    }
}

/// SQL apply step generated by the conflict-policy reconciler.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct ConflictPolicyApplyStep {
    pub name: String,
    pub sql: String,
    pub idempotent: bool,
}

impl ConflictPolicyApplyStep {
    fn new(name: impl Into<String>, sql: impl Into<String>, idempotent: bool) -> Self {
        Self {
            name: name.into(),
            sql: sql.into(),
            idempotent,
        }
    }
}

/// Apply plan composed of `ConflictPolicyApplyStep`s in execution order.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct ConflictPolicyApplyPlan {
    pub steps: Vec<ConflictPolicyApplyStep>,
}

impl ConflictPolicyApplyPlan {
    pub fn sql_script(&self) -> String {
        self.steps
            .iter()
            .map(|step| step.sql.trim_end())
            .collect::<Vec<_>>()
            .join("\n")
    }
}

fn register_policy_sql(plan: &ConflictPolicyReconcilePlan) -> String {
    format!(
        "SELECT {function}({name}, {table}, {class}, {resolution}, {custom});",
        function = COMPANION_REGISTER_POLICY_FUNCTION,
        name = sql_literal(&plan.policy_name),
        table = sql_literal(&plan.table),
        class = sql_literal(plan.class_str()),
        resolution = sql_literal(plan.resolution_str()),
        custom = optional_sql_literal(&plan.custom_function),
    )
}

fn validate_custom_function_sql(function: &str) -> String {
    format!(
        "SELECT {validate}({function});",
        validate = COMPANION_VALIDATE_CUSTOM_FUNCTION,
        function = sql_literal(function),
    )
}

fn sql_literal(value: &str) -> String {
    format!("'{}'", value.replace('\'', "''"))
}

fn optional_sql_literal(value: &Option<String>) -> String {
    value
        .as_deref()
        .map(sql_literal)
        .unwrap_or_else(|| "NULL".to_string())
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub enum ConflictPolicyReconcileError {
    InvalidSpec(ConflictPolicySpecError),
    MissingPolicyName,
}

impl fmt::Display for ConflictPolicyReconcileError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidSpec(error) => write!(formatter, "{error}"),
            Self::MissingPolicyName => write!(formatter, "policy_name must not be empty"),
        }
    }
}

impl Error for ConflictPolicyReconcileError {}

impl From<ConflictPolicySpecError> for ConflictPolicyReconcileError {
    fn from(error: ConflictPolicySpecError) -> Self {
        Self::InvalidSpec(error)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn update_update_plan_renders_last_write_wins_resolution() {
        let spec = ConflictPolicySpec {
            table: "public.reference_accounts".to_string(),
            class: ConflictClass::UpdateUpdate,
            resolution: ConflictResolution::LastWriteWins,
            custom_function: None,
        };

        let plan = ConflictPolicyReconcilePlan::from_spec("accounts-lww", &spec)
            .expect("valid plan");

        assert_eq!(plan.policy_name, "accounts-lww");
        assert_eq!(plan.class_str(), "update_origin_differs");
        assert_eq!(plan.resolution_str(), "apply_remote_if_newer");

        let apply_plan = plan.apply_plan();
        assert_eq!(apply_plan.steps.len(), 2);
        assert_eq!(apply_plan.steps[0].name, "ensure_ai_blaise_citus_extension");
        assert_eq!(apply_plan.steps[1].name, "register_conflict_policy");
        assert!(apply_plan.steps[1]
            .sql
            .contains("companion_internal.replication_conflict_policy_register"));
        assert!(apply_plan.steps[1].sql.contains("'accounts-lww'"));
        assert!(apply_plan.steps[1]
            .sql
            .contains("'public.reference_accounts'"));
        assert!(apply_plan.steps[1].sql.contains("'update_origin_differs'"));
        assert!(apply_plan.steps[1].sql.contains("'apply_remote_if_newer'"));
        assert!(apply_plan.steps[1].sql.ends_with(", NULL);"));

        let teardown = plan.teardown_sql();
        assert!(
            teardown.contains("companion_internal.replication_conflict_policy_unregister")
        );
        assert!(teardown.contains("'accounts-lww'"));

        let status = plan.status_sql();
        assert!(status.contains("companion.replication_conflict_status"));
        assert!(status.contains("'accounts-lww'"));
    }

    #[test]
    fn custom_function_plan_inserts_validation_step() {
        let spec = ConflictPolicySpec {
            table: "public.merge_targets".to_string(),
            class: ConflictClass::InsertUpdate,
            resolution: ConflictResolution::CustomFunction,
            custom_function: Some("public.merge_remote_into_local".to_string()),
        };

        let plan =
            ConflictPolicyReconcilePlan::from_spec("merge-policy", &spec).expect("valid plan");

        assert_eq!(plan.class_str(), "update_missing");
        assert_eq!(plan.resolution_str(), "merge_function");

        let apply_plan = plan.apply_plan();
        assert_eq!(apply_plan.steps.len(), 3);
        assert_eq!(apply_plan.steps[1].name, "validate_custom_function");
        assert!(apply_plan.steps[1]
            .sql
            .contains("replication_conflict_validate_function"));
        assert!(apply_plan.steps[1]
            .sql
            .contains("'public.merge_remote_into_local'"));
        assert!(apply_plan.steps[2]
            .sql
            .contains("'public.merge_remote_into_local'"));
        assert!(!apply_plan.steps[2].sql.contains(", NULL);"));
    }

    #[test]
    fn all_seven_classes_map_to_spock_strings() {
        let cases = [
            (ConflictClass::InsertInsert, "insert_exists"),
            (ConflictClass::InsertUpdate, "update_missing"),
            (ConflictClass::UpdateUpdate, "update_origin_differs"),
            (ConflictClass::UpdateDelete, "update_pkey_exists"),
            (ConflictClass::DeleteUpdate, "delete_origin_differs"),
            (ConflictClass::DeleteDelete, "delete_missing"),
            (ConflictClass::Constraint, "update_concurrent"),
        ];

        for (class, expected) in cases {
            let spec = ConflictPolicySpec {
                table: "public.t".to_string(),
                class,
                resolution: ConflictResolution::LastWriteWins,
                custom_function: None,
            };
            let plan = ConflictPolicyReconcilePlan::from_spec("policy", &spec)
                .expect("valid plan");
            assert_eq!(plan.class_str(), expected, "class string mismatch");
        }
    }

    #[test]
    fn all_resolutions_map_to_companion_strings() {
        let cases = [
            (ConflictResolution::LastWriteWins, "apply_remote_if_newer"),
            (ConflictResolution::OriginWins, "apply_remote"),
            (ConflictResolution::TargetWins, "keep_local"),
            (ConflictResolution::Skip, "keep_local"),
            (ConflictResolution::Error, "error"),
            (ConflictResolution::CustomFunction, "merge_function"),
        ];

        for (resolution, expected) in cases {
            let spec = ConflictPolicySpec {
                table: "public.t".to_string(),
                class: ConflictClass::UpdateUpdate,
                resolution,
                custom_function: matches!(resolution, ConflictResolution::CustomFunction)
                    .then(|| "public.merge".to_string()),
            };
            let plan = ConflictPolicyReconcilePlan::from_spec("policy", &spec)
                .expect("valid plan");
            assert_eq!(plan.resolution_str(), expected, "resolution mismatch");
        }
    }

    #[test]
    fn empty_policy_name_is_rejected() {
        let spec = ConflictPolicySpec {
            table: "public.t".to_string(),
            class: ConflictClass::UpdateUpdate,
            resolution: ConflictResolution::LastWriteWins,
            custom_function: None,
        };

        assert_eq!(
            ConflictPolicyReconcilePlan::from_spec("  ", &spec),
            Err(ConflictPolicyReconcileError::MissingPolicyName)
        );
    }

    #[test]
    fn missing_custom_function_propagates_validation_error() {
        let spec = ConflictPolicySpec {
            table: "public.t".to_string(),
            class: ConflictClass::UpdateUpdate,
            resolution: ConflictResolution::CustomFunction,
            custom_function: None,
        };

        assert_eq!(
            ConflictPolicyReconcilePlan::from_spec("policy", &spec),
            Err(ConflictPolicyReconcileError::InvalidSpec(
                ConflictPolicySpecError::MissingRequiredField("custom_function")
            ))
        );
    }

    #[test]
    fn quoted_table_is_escaped_for_sql() {
        let spec = ConflictPolicySpec {
            table: "public.\"weird'name\"".to_string(),
            class: ConflictClass::UpdateUpdate,
            resolution: ConflictResolution::LastWriteWins,
            custom_function: None,
        };

        let plan =
            ConflictPolicyReconcilePlan::from_spec("policy", &spec).expect("valid plan");
        let script = plan.apply_sql_script();
        assert!(script.contains("'public.\"weird''name\"'"));
    }
}
