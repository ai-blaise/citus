// FEATURE: C9
// FEATURE: C10
// FEATURE: M3

use std::error::Error;
use std::fmt;

use crate::crds::migration::{
    MigrationConflictAction, MigrationSpec, MigrationSpecError, MigrationType,
};

/// Schema-qualified helper used by the reconciler to hand the inline YAML DSL
/// to the companion migration runtime. The companion side parses the DSL,
/// records the migration in `companion_migrations`, and drives the schema-job
/// state machine through `delete_only -> write_only -> backfill -> public`.
pub const COMPANION_MIGRATION_APPLY_FUNCTION: &str = "companion_internal.migration_apply";

/// Schema-qualified helper invoked when the CR is deleted mid-flight.
pub const COMPANION_MIGRATION_PAUSE_FUNCTION: &str = "companion_internal.migration_pause";

/// Schema-qualified helper invoked when the CR is deleted with the explicit
/// `abort` action. The companion runtime rolls the schema-job back to the
/// previous public state.
pub const COMPANION_MIGRATION_ABORT_FUNCTION: &str = "companion_internal.migration_abort";

/// Schema-qualified helper used to advance the schema-job state machine.
pub const COMPANION_MIGRATION_ADVANCE_FUNCTION: &str = "companion_internal.migration_advance";

/// Schema-qualified helper used to read the current schema-job state. The
/// reconciler uses it to populate the CR's `.status.currentPhase` and
/// `.status.percentComplete` fields.
pub const COMPANION_MIGRATION_STATUS_VIEW: &str = "companion.migration_status";

/// Ordered phases the schema-job state machine walks through. The order is
/// load-bearing because the reconciler advances phases in this sequence and
/// the canonical SQL apply plan inserts a guard for each transition.
pub const MIGRATION_PHASES: &[MigrationPhase] = &[
    MigrationPhase::DeleteOnly,
    MigrationPhase::WriteOnly,
    MigrationPhase::Backfill,
    MigrationPhase::Public,
];

/// Schema-job phase mirrored from `companion::SchemaJobState`. The reconciler
/// maps the schema-job state cursor through these phases; they are duplicated
/// here so the operator does not need to depend on `companion::SchemaJobState`
/// at the CRD layer.
#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum MigrationPhase {
    DeleteOnly,
    WriteOnly,
    Backfill,
    Public,
}

impl MigrationPhase {
    /// Schema-job state name used by the companion runtime.
    pub fn as_companion_str(self) -> &'static str {
        match self {
            Self::DeleteOnly => "delete_only",
            Self::WriteOnly => "write_only",
            Self::Backfill => "backfill",
            Self::Public => "public",
        }
    }
}

impl fmt::Display for MigrationPhase {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(self.as_companion_str())
    }
}

/// Resolved reconcile plan derived from a `MigrationSpec`. The plan captures
/// everything required to invoke `companion_internal.migration_apply` with
/// the inline DSL and to advance the schema-job state machine to `public`.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct MigrationReconcilePlan {
    pub migration_name: String,
    pub migration_type: MigrationType,
    pub yaml: String,
    pub on_conflict: MigrationConflictAction,
    pub phases: Vec<MigrationPhase>,
}

impl MigrationReconcilePlan {
    /// Build a reconcile plan from the named Migration CR. `migration_name`
    /// is the `metadata.name` of the owning CRD so the schema-job key is
    /// deterministic across reconciliation passes.
    pub fn from_spec(
        migration_name: &str,
        spec: &MigrationSpec,
    ) -> Result<Self, MigrationReconcileError> {
        let trimmed_name = migration_name.trim();
        if trimmed_name.is_empty() {
            return Err(MigrationReconcileError::MissingMigrationName);
        }
        spec.validate()?;

        Ok(Self {
            migration_name: trimmed_name.to_string(),
            migration_type: spec.migration_type,
            yaml: spec.yaml.clone(),
            on_conflict: spec.on_conflict,
            phases: MIGRATION_PHASES.to_vec(),
        })
    }

    /// Migration-type string accepted by the companion runtime.
    pub fn migration_type_str(&self) -> &'static str {
        match self.migration_type {
            MigrationType::Pgroll => "pgroll",
            MigrationType::GhOst => "gh-ost",
        }
    }

    /// `on_conflict` string accepted by the companion runtime. Mirrors the
    /// `abort | rebase | skip | manual_review` taxonomy from the CRD spec.
    pub fn on_conflict_str(&self) -> &'static str {
        match self.on_conflict {
            MigrationConflictAction::Fail => "abort",
            MigrationConflictAction::Skip => "skip",
            MigrationConflictAction::Replace => "rebase",
            MigrationConflictAction::ManualReview => "manual_review",
        }
    }

    /// Render the SQL apply plan that records the migration, hands the DSL to
    /// the companion runtime, and advances the schema-job state machine.
    pub fn apply_plan(&self) -> MigrationApplyPlan {
        let mut steps = vec![
            MigrationApplyStep::new(
                "ensure_ai_blaise_citus_extension",
                "CREATE EXTENSION IF NOT EXISTS ai_blaise_citus;",
                true,
            ),
            MigrationApplyStep::new(
                "apply_companion_migration",
                migration_apply_sql(self),
                false,
            ),
        ];

        for phase in &self.phases {
            steps.push(MigrationApplyStep::new(
                format!("advance_to_{}", phase.as_companion_str()),
                advance_phase_sql(&self.migration_name, *phase),
                true,
            ));
        }

        MigrationApplyPlan { steps }
    }

    /// Render the apply-plan SQL script directly.
    pub fn apply_sql_script(&self) -> String {
        self.apply_plan().sql_script()
    }

    /// Render the teardown SQL run when the CR is deleted mid-flight. The
    /// reconciler pauses by default; only an explicit abort flag triggers the
    /// rollback so a half-applied migration is never silently dropped.
    pub fn teardown_sql(&self, action: TeardownAction) -> String {
        match action {
            TeardownAction::Pause => format!(
                "SELECT {function}({name});",
                function = COMPANION_MIGRATION_PAUSE_FUNCTION,
                name = sql_literal(&self.migration_name),
            ),
            TeardownAction::Abort => format!(
                "SELECT {function}({name});",
                function = COMPANION_MIGRATION_ABORT_FUNCTION,
                name = sql_literal(&self.migration_name),
            ),
        }
    }

    /// Render the status SQL used to populate the CR's `.status` fields.
    pub fn status_sql(&self) -> String {
        format!(
            "SELECT phase, percent_complete, eta_seconds FROM {view} WHERE migration = {name};",
            view = COMPANION_MIGRATION_STATUS_VIEW,
            name = sql_literal(&self.migration_name),
        )
    }
}

/// Teardown action applied when a Migration CR is removed. Pause is the
/// default; Abort requires an explicit user opt-in because rolling back a
/// schema-job mid-flight can drop in-flight rows.
#[derive(Debug, Clone, Copy, Eq, PartialEq)]
pub enum TeardownAction {
    Pause,
    Abort,
}

/// SQL apply step generated by the migration reconciler.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct MigrationApplyStep {
    pub name: String,
    pub sql: String,
    pub idempotent: bool,
}

impl MigrationApplyStep {
    fn new(name: impl Into<String>, sql: impl Into<String>, idempotent: bool) -> Self {
        Self {
            name: name.into(),
            sql: sql.into(),
            idempotent,
        }
    }
}

/// Apply plan composed of `MigrationApplyStep`s in execution order.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct MigrationApplyPlan {
    pub steps: Vec<MigrationApplyStep>,
}

impl MigrationApplyPlan {
    pub fn sql_script(&self) -> String {
        self.steps
            .iter()
            .map(|step| step.sql.trim_end())
            .collect::<Vec<_>>()
            .join("\n")
    }
}

fn migration_apply_sql(plan: &MigrationReconcilePlan) -> String {
    format!(
        "SELECT {function}({name}, {migration_type}, {on_conflict}, {yaml});",
        function = COMPANION_MIGRATION_APPLY_FUNCTION,
        name = sql_literal(&plan.migration_name),
        migration_type = sql_literal(plan.migration_type_str()),
        on_conflict = sql_literal(plan.on_conflict_str()),
        yaml = sql_literal(&plan.yaml),
    )
}

fn advance_phase_sql(name: &str, phase: MigrationPhase) -> String {
    format!(
        "SELECT {function}({name}, {phase});",
        function = COMPANION_MIGRATION_ADVANCE_FUNCTION,
        name = sql_literal(name),
        phase = sql_literal(phase.as_companion_str()),
    )
}

fn sql_literal(value: &str) -> String {
    format!("'{}'", value.replace('\'', "''"))
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub enum MigrationReconcileError {
    InvalidSpec(MigrationSpecError),
    MissingMigrationName,
}

impl fmt::Display for MigrationReconcileError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidSpec(error) => write!(formatter, "{error}"),
            Self::MissingMigrationName => write!(formatter, "migration_name must not be empty"),
        }
    }
}

impl Error for MigrationReconcileError {}

impl From<MigrationSpecError> for MigrationReconcileError {
    fn from(error: MigrationSpecError) -> Self {
        Self::InvalidSpec(error)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pgroll_plan_renders_companion_apply_and_phase_advances() {
        let spec = MigrationSpec {
            migration_type: MigrationType::Pgroll,
            yaml: "operations:\n  - add_column:\n      table: users\n      column: display_name"
                .to_string(),
            on_conflict: MigrationConflictAction::ManualReview,
        };

        let plan = MigrationReconcilePlan::from_spec("users-add-display-name", &spec)
            .expect("valid plan");

        assert_eq!(plan.migration_name, "users-add-display-name");
        assert_eq!(plan.migration_type_str(), "pgroll");
        assert_eq!(plan.on_conflict_str(), "manual_review");
        assert_eq!(plan.phases.len(), 4);

        let apply_plan = plan.apply_plan();
        assert_eq!(apply_plan.steps.len(), 6);
        assert_eq!(apply_plan.steps[0].name, "ensure_ai_blaise_citus_extension");
        assert!(apply_plan.steps[0].idempotent);
        assert_eq!(apply_plan.steps[1].name, "apply_companion_migration");
        assert!(!apply_plan.steps[1].idempotent);
        assert!(apply_plan.steps[1]
            .sql
            .contains("companion_internal.migration_apply"));
        assert!(apply_plan.steps[1].sql.contains("'pgroll'"));
        assert!(apply_plan.steps[1].sql.contains("'manual_review'"));
        assert!(apply_plan.steps[1]
            .sql
            .contains("'users-add-display-name'"));
        assert_eq!(apply_plan.steps[2].name, "advance_to_delete_only");
        assert_eq!(apply_plan.steps[3].name, "advance_to_write_only");
        assert_eq!(apply_plan.steps[4].name, "advance_to_backfill");
        assert_eq!(apply_plan.steps[5].name, "advance_to_public");
        assert!(apply_plan.steps[5].idempotent);
        assert!(apply_plan.steps[5].sql.contains("'public'"));

        let status_sql = plan.status_sql();
        assert!(status_sql.contains("companion.migration_status"));
        assert!(status_sql.contains("'users-add-display-name'"));

        let pause = plan.teardown_sql(TeardownAction::Pause);
        assert!(pause.contains("companion_internal.migration_pause"));
        let abort = plan.teardown_sql(TeardownAction::Abort);
        assert!(abort.contains("companion_internal.migration_abort"));
    }

    #[test]
    fn gh_ost_plan_renders_correct_migration_type_and_conflict_strings() {
        let spec = MigrationSpec {
            migration_type: MigrationType::GhOst,
            yaml: "operations:\n  - rename_column:\n      from: legacy_id\n      to: id".to_string(),
            on_conflict: MigrationConflictAction::Fail,
        };

        let plan =
            MigrationReconcilePlan::from_spec("orders-rename-id", &spec).expect("valid plan");

        assert_eq!(plan.migration_type_str(), "gh-ost");
        assert_eq!(plan.on_conflict_str(), "abort");
        let script = plan.apply_sql_script();
        assert!(script.contains("'gh-ost'"));
        assert!(script.contains("'abort'"));
    }

    #[test]
    fn rebase_and_skip_conflict_actions_render_correctly() {
        let spec_replace = MigrationSpec {
            migration_type: MigrationType::Pgroll,
            yaml: "operations: []".to_string(),
            on_conflict: MigrationConflictAction::Replace,
        };
        let plan_replace =
            MigrationReconcilePlan::from_spec("replace-mig", &spec_replace).expect("valid plan");
        assert_eq!(plan_replace.on_conflict_str(), "rebase");

        let spec_skip = MigrationSpec {
            migration_type: MigrationType::Pgroll,
            yaml: "operations: []".to_string(),
            on_conflict: MigrationConflictAction::Skip,
        };
        let plan_skip =
            MigrationReconcilePlan::from_spec("skip-mig", &spec_skip).expect("valid plan");
        assert_eq!(plan_skip.on_conflict_str(), "skip");
    }

    #[test]
    fn empty_migration_name_is_rejected() {
        let spec = MigrationSpec {
            migration_type: MigrationType::Pgroll,
            yaml: "operations: []".to_string(),
            on_conflict: MigrationConflictAction::Fail,
        };

        assert_eq!(
            MigrationReconcilePlan::from_spec("   ", &spec),
            Err(MigrationReconcileError::MissingMigrationName)
        );
    }

    #[test]
    fn invalid_spec_propagates_validation_error() {
        let spec = MigrationSpec {
            migration_type: MigrationType::Pgroll,
            yaml: String::new(),
            on_conflict: MigrationConflictAction::Fail,
        };

        assert_eq!(
            MigrationReconcilePlan::from_spec("empty-yaml", &spec),
            Err(MigrationReconcileError::InvalidSpec(
                MigrationSpecError::MissingRequiredField("yaml")
            ))
        );
    }

    #[test]
    fn single_quotes_in_yaml_are_escaped_for_sql() {
        let spec = MigrationSpec {
            migration_type: MigrationType::Pgroll,
            yaml: "operations:\n  - add_column:\n      default: 'O''Reilly'".to_string(),
            on_conflict: MigrationConflictAction::ManualReview,
        };

        let plan =
            MigrationReconcilePlan::from_spec("escape-test", &spec).expect("valid plan");
        let script = plan.apply_sql_script();
        assert!(script.contains("''O''''Reilly''"));
    }

    #[test]
    fn migration_phase_display_matches_companion_state() {
        assert_eq!(format!("{}", MigrationPhase::DeleteOnly), "delete_only");
        assert_eq!(format!("{}", MigrationPhase::WriteOnly), "write_only");
        assert_eq!(format!("{}", MigrationPhase::Backfill), "backfill");
        assert_eq!(format!("{}", MigrationPhase::Public), "public");
    }
}
