#!/usr/bin/env bash
# FEATURE: F1
# FEATURE: F3
# FEATURE: Search7
# FEATURE: Search2
# FEATURE: WH1
# FEATURE: WH2
# FEATURE: EF3

# FederationReconciler + SearchIndexReconciler + WebhookReconciler +
# FunctionReconciler plan-builder smoke. Applies a canonical CR for each of
# Federation (Snowflake -> Iceberg bridge), SearchIndex (BM25 + vector hybrid),
# Webhook (orders INSERT/UPDATE), and Function (HTTP + event-driven Deno), to
# the kind cluster, verifies each CR round-trips through the API server, and
# runs the operator's reconciler plan-builders so we have executable evidence
# that the same plan-builders used by the operator deployment image emit the
# canonical reconcile-plan TSV row for the canonical specs. A live in-cluster
# Kubernetes controller loop (watch + .status update) for these four CRDs
# remains alpha because the production operator runtime currently exposes only
# health/readiness/metrics and plan-builder helpers.

set -euo pipefail

cluster="${KIND_CLUSTER:-ai-blaise-citus-smoke}"
namespace="${KIND_NAMESPACE:-ai-blaise-citus}"

require_kubectl() {
  if ! command -v kubectl >/dev/null 2>&1; then
    echo "kubectl not available; skipping reconcilers batch-b smoke" >&2
    exit 0
  fi
}

require_cargo() {
  if ! command -v cargo >/dev/null 2>&1; then
    if [[ -f "${HOME}/.cargo/env" ]]; then
      # shellcheck disable=SC1091
      source "${HOME}/.cargo/env"
    fi
  fi
  if ! command -v cargo >/dev/null 2>&1; then
    echo "cargo not available; skipping reconcilers batch-b smoke" >&2
    exit 0
  fi
}

require_cluster() {
  if ! kubectl --context "kind-${cluster}" get ns >/dev/null 2>&1; then
    echo "kind cluster ${cluster} not available; skipping reconcilers batch-b smoke" >&2
    exit 0
  fi
}

apply_canonical_crs() {
  local federation_name="reconcilers-batch-b-federation"
  local search_name="reconcilers-batch-b-search"
  local webhook_name="reconcilers-batch-b-webhook"
  local function_name="reconcilers-batch-b-function"

  kubectl --context "kind-${cluster}" -n "${namespace}" delete federation "${federation_name}" >/dev/null 2>&1 || true
  kubectl --context "kind-${cluster}" -n "${namespace}" delete searchindex "${search_name}" >/dev/null 2>&1 || true
  kubectl --context "kind-${cluster}" -n "${namespace}" delete webhook "${webhook_name}" >/dev/null 2>&1 || true
  kubectl --context "kind-${cluster}" -n "${namespace}" delete function "${function_name}" >/dev/null 2>&1 || true

  cat <<YAML | kubectl --context "kind-${cluster}" apply -n "${namespace}" -f -
apiVersion: ai-blaise.com/v1alpha1
kind: Federation
metadata:
  name: ${federation_name}
spec:
  type: snowflake
  connection:
    secretRef: snowflake-warehouse
  foreignSchemaPrefix: snowflake_raw
---
apiVersion: ai-blaise.com/v1alpha1
kind: SearchIndex
metadata:
  name: ${search_name}
spec:
  table: public.documents
  scorer: bm25+vector
  analyzer: english
  distributed: true
  columns:
    - name: body
      kind: text
    - name: embedding
      kind: vector
---
apiVersion: ai-blaise.com/v1alpha1
kind: Webhook
metadata:
  name: ${webhook_name}
spec:
  table: public.orders
  events:
    - INSERT
    - UPDATE
  url: https://hooks.example.com/orders
  headersSecretRef: orders-webhook-headers
  retryPolicy:
    maxAttempts: 5
    backoff: exponential:1s:30s
    deadLetterTable: companion.webhook_dead_letters
  payloadTemplate: |
    {"table":"orders"}
---
apiVersion: ai-blaise.com/v1alpha1
kind: Function
metadata:
  name: ${function_name}
spec:
  name: order-created
  runtime: deno
  source:
    gitRef:
      repository: https://github.com/ai-blaise/functions
      reference: main
      path: orders/index.ts
  triggers:
    - http:
        path: /orders
    - event:
        table: public.orders
        event: INSERT
  envSecrets:
    - orders-api-key
YAML

  verify_round_trip "federation" "${federation_name}"
  verify_round_trip "searchindex" "${search_name}"
  verify_round_trip "webhook" "${webhook_name}"
  verify_round_trip "function" "${function_name}"

  kubectl --context "kind-${cluster}" -n "${namespace}" delete federation "${federation_name}" >/dev/null 2>&1 || true
  kubectl --context "kind-${cluster}" -n "${namespace}" delete searchindex "${search_name}" >/dev/null 2>&1 || true
  kubectl --context "kind-${cluster}" -n "${namespace}" delete webhook "${webhook_name}" >/dev/null 2>&1 || true
  kubectl --context "kind-${cluster}" -n "${namespace}" delete function "${function_name}" >/dev/null 2>&1 || true
}

verify_round_trip() {
  local kind="$1"
  local name="$2"
  local uid
  uid="$(kubectl --context "kind-${cluster}" -n "${namespace}" get "${kind}" "${name}" -o jsonpath='{.metadata.uid}')"
  if [[ -z "${uid}" ]]; then
    echo "${kind} CR ${name} did not round-trip through the API server" >&2
    exit 1
  fi
}

run_reconcilers_batch_b_plan_builder() {
  local output
  if ! output="$(cargo run -q -p ai_blaise_citus_operator -- run-reconcilers-batch-b 2>/dev/null)"; then
    echo "operator run-reconcilers-batch-b failed for canonical CR specs" >&2
    exit 1
  fi

  local expected=$'federation_apply_steps\tfederation_iceberg\tsearch_apply_steps\tsearch_hybrid\twebhook_apply_steps\twebhook_events\tfunction_apply_steps\tfunction_sidecar_steps\tfunction_kubernetes_steps\n3\ttrue\t4\ttrue\t5\t2\t6\t1\t2'
  if [[ "${output}" != "${expected}" ]]; then
    echo "operator run-reconcilers-batch-b did not emit expected canonical TSV row" >&2
    printf '%s\n' "${output}" >&2
    exit 1
  fi
}

main() {
  require_cargo
  run_reconcilers_batch_b_plan_builder

  if [[ "${SKIP_KIND:-0}" == "1" ]]; then
    echo "ai_blaise_citus reconcilers batch-b plan-builder smoke passed (kind apply skipped)"
    return 0
  fi

  require_kubectl
  require_cluster
  apply_canonical_crs

  echo "ai_blaise_citus reconcilers batch-b smoke passed in kind/${cluster}/${namespace}"
}

main "$@"
