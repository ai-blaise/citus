//! Closed-timestamp follower-read runtime contract.
//!
//! Bridges the HLC sidecar's `/closed_ts` plan to a coordinator-side
//! `companion.follower_read(...)` SQL function. The runtime is intentionally
//! deterministic so the production-readiness audit can verify the
//! coordinator never reads past the closed timestamp.

// FEATURE: MR6
// FEATURE: MR6R
// FEATURE: S9R

use std::error::Error;
use std::fmt;

/// Coordinator-side closed-timestamp read request.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct ClosedTimestampReadRequest {
    pub shard_group: String,
    pub as_of_physical_ms: u64,
    pub max_staleness_ms: u64,
}

impl ClosedTimestampReadRequest {
    pub fn validate(&self) -> Result<(), ClosedTimestampReaderError> {
        if self.shard_group.trim().is_empty() {
            return Err(ClosedTimestampReaderError::MissingShardGroup);
        }
        if self.as_of_physical_ms == 0 {
            return Err(ClosedTimestampReaderError::InvalidAsOf);
        }
        if self.max_staleness_ms == 0 {
            return Err(ClosedTimestampReaderError::ZeroStalenessBudget);
        }
        Ok(())
    }
}

/// Decision returned to the coordinator after consulting the HLC closed
/// timestamp.
#[derive(Debug, Clone, Eq, PartialEq)]
pub enum ClosedTimestampReadDecision {
    /// Read is safe at the requested `as_of` from any follower replica.
    ServeFromFollower {
        shard_group: String,
        as_of_physical_ms: u64,
        closed_at_physical_ms: u64,
    },
    /// Read is too fresh; the coordinator must fall back to the leader to
    /// preserve linearizability.
    RouteToLeader {
        shard_group: String,
        as_of_physical_ms: u64,
        closed_at_physical_ms: u64,
        reason: String,
    },
}

/// Closed-timestamp plan as observed from the HLC sidecar.
#[derive(Debug, Clone, Eq, PartialEq)]
pub struct ClosedTimestampSnapshot {
    pub shard_group: String,
    pub closed_at_physical_ms: u64,
    pub max_staleness_ms: u64,
}

impl ClosedTimestampSnapshot {
    pub fn validate(&self) -> Result<(), ClosedTimestampReaderError> {
        if self.shard_group.trim().is_empty() {
            return Err(ClosedTimestampReaderError::MissingShardGroup);
        }
        if self.closed_at_physical_ms == 0 {
            return Err(ClosedTimestampReaderError::ZeroClosedTimestamp);
        }
        if self.max_staleness_ms == 0 {
            return Err(ClosedTimestampReaderError::ZeroStalenessBudget);
        }
        Ok(())
    }
}

/// Decide whether a read at `as_of_physical_ms` is safe given the current
/// closed timestamp.
pub fn decide_follower_read(
    request: &ClosedTimestampReadRequest,
    snapshot: &ClosedTimestampSnapshot,
) -> Result<ClosedTimestampReadDecision, ClosedTimestampReaderError> {
    request.validate()?;
    snapshot.validate()?;

    if request.shard_group != snapshot.shard_group {
        return Err(ClosedTimestampReaderError::ShardGroupMismatch);
    }
    if request.max_staleness_ms != snapshot.max_staleness_ms {
        return Err(ClosedTimestampReaderError::StalenessBudgetMismatch);
    }
    if request.as_of_physical_ms > snapshot.closed_at_physical_ms {
        return Ok(ClosedTimestampReadDecision::RouteToLeader {
            shard_group: request.shard_group.clone(),
            as_of_physical_ms: request.as_of_physical_ms,
            closed_at_physical_ms: snapshot.closed_at_physical_ms,
            reason: "as_of newer than closed_at".to_string(),
        });
    }
    let staleness = snapshot
        .closed_at_physical_ms
        .saturating_sub(request.as_of_physical_ms);
    if staleness > request.max_staleness_ms {
        return Ok(ClosedTimestampReadDecision::RouteToLeader {
            shard_group: request.shard_group.clone(),
            as_of_physical_ms: request.as_of_physical_ms,
            closed_at_physical_ms: snapshot.closed_at_physical_ms,
            reason: format!(
                "staleness {staleness} ms exceeds max_staleness_ms {}",
                request.max_staleness_ms
            ),
        });
    }
    Ok(ClosedTimestampReadDecision::ServeFromFollower {
        shard_group: request.shard_group.clone(),
        as_of_physical_ms: request.as_of_physical_ms,
        closed_at_physical_ms: snapshot.closed_at_physical_ms,
    })
}

#[derive(Debug, Clone, Eq, PartialEq)]
pub enum ClosedTimestampReaderError {
    InvalidAsOf,
    MissingShardGroup,
    ShardGroupMismatch,
    StalenessBudgetMismatch,
    ZeroClosedTimestamp,
    ZeroStalenessBudget,
}

impl fmt::Display for ClosedTimestampReaderError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidAsOf => write!(formatter, "as_of_physical_ms must be greater than zero"),
            Self::MissingShardGroup => write!(formatter, "shard_group must be set"),
            Self::ShardGroupMismatch => {
                write!(
                    formatter,
                    "request and snapshot must target the same shard_group"
                )
            }
            Self::StalenessBudgetMismatch => {
                write!(
                    formatter,
                    "request and snapshot must agree on max_staleness_ms"
                )
            }
            Self::ZeroClosedTimestamp => {
                write!(formatter, "closed_at_physical_ms must be greater than zero")
            }
            Self::ZeroStalenessBudget => {
                write!(formatter, "max_staleness_ms must be greater than zero")
            }
        }
    }
}

impl Error for ClosedTimestampReaderError {}

pub fn canonical_closed_ts_request() -> ClosedTimestampReadRequest {
    ClosedTimestampReadRequest {
        shard_group: "orders-sg".to_string(),
        as_of_physical_ms: 1_699_999_500,
        max_staleness_ms: 5_000,
    }
}

pub fn canonical_closed_ts_snapshot() -> ClosedTimestampSnapshot {
    ClosedTimestampSnapshot {
        shard_group: "orders-sg".to_string(),
        closed_at_physical_ms: 1_699_999_550,
        max_staleness_ms: 5_000,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn safe_read_serves_from_follower() {
        let decision = decide_follower_read(
            &canonical_closed_ts_request(),
            &canonical_closed_ts_snapshot(),
        )
        .expect("decision");
        assert!(matches!(
            decision,
            ClosedTimestampReadDecision::ServeFromFollower { .. }
        ));
    }

    #[test]
    fn fresh_read_routes_to_leader() {
        let request = ClosedTimestampReadRequest {
            shard_group: "orders-sg".to_string(),
            as_of_physical_ms: 1_700_000_000,
            max_staleness_ms: 5_000,
        };
        let snapshot = ClosedTimestampSnapshot {
            shard_group: "orders-sg".to_string(),
            closed_at_physical_ms: 1_699_999_500,
            max_staleness_ms: 5_000,
        };
        let decision = decide_follower_read(&request, &snapshot).expect("decision");
        match decision {
            ClosedTimestampReadDecision::RouteToLeader { reason, .. } => {
                assert!(reason.contains("as_of newer than closed_at"));
            }
            other => panic!("expected RouteToLeader, got {other:?}"),
        }
    }

    #[test]
    fn stale_read_routes_to_leader() {
        let request = ClosedTimestampReadRequest {
            shard_group: "orders-sg".to_string(),
            as_of_physical_ms: 1_699_990_000,
            max_staleness_ms: 5_000,
        };
        let snapshot = canonical_closed_ts_snapshot();
        let decision = decide_follower_read(&request, &snapshot).expect("decision");
        match decision {
            ClosedTimestampReadDecision::RouteToLeader { reason, .. } => {
                assert!(reason.contains("staleness"));
            }
            other => panic!("expected RouteToLeader, got {other:?}"),
        }
    }

    #[test]
    fn mismatched_shard_groups_error() {
        let request = canonical_closed_ts_request();
        let mut snapshot = canonical_closed_ts_snapshot();
        snapshot.shard_group = "other-sg".to_string();
        let result = decide_follower_read(&request, &snapshot);
        assert_eq!(
            result.err(),
            Some(ClosedTimestampReaderError::ShardGroupMismatch)
        );
    }
}
