#!/usr/bin/env python3
"""Synthetic custody controls; never inspect or mutate actual qualification proofs.

All fixture files remain under a fresh directory within the proof RUN directory.
The imported sealer's proof roots and byte cache are rebound only in this process.
No checkout operation, real source verification, or real seal is performed.
"""
import gzip
import hashlib
import importlib.util
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock


sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
HELPER = HERE / "seal.py"
SPEC = importlib.util.spec_from_file_location("rustls_seal_custody_under_test", HELPER)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError("cannot load sealer module")
seal = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(seal)


class CustodyControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if seal.RUN != HERE:
            raise RuntimeError("test and sealer must share the expected proof RUN")
        cls.suite_root = Path(tempfile.mkdtemp(prefix="seal-custody-tests-", dir=HERE))
        print("FIXTURES_PRESERVED=" + str(cls.suite_root), file=sys.stderr, flush=True)
        print("SEALER_SHA256=" + hashlib.sha256(HELPER.read_bytes()).hexdigest(),
              file=sys.stderr, flush=True)
        print("CONTROL_SOURCE_SHA256=" + hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              file=sys.stderr, flush=True)

    def setUp(self):
        self.case = Path(tempfile.mkdtemp(prefix=self._testMethodName + "-", dir=self.suite_root))
        self.output = self.case / "captured"
        self.output.mkdir()
        for name, value in [
            ("RUN", self.case),
            ("CI", self.case / "unused-ci"),
            ("PROOF_BYTES", {}),
        ]:
            patcher = mock.patch.object(seal, name, value)
            patcher.start()
            self.addCleanup(patcher.stop)
        patcher = mock.patch.object(
            seal, "git", side_effect=AssertionError("synthetic controls must not call git")
        )
        self.git_mock = patcher.start()
        self.addCleanup(patcher.stop)

    def tearDown(self):
        self.git_mock.assert_not_called()

    def fixture(self, name, data):
        path = self.case / name
        with path.open("xb") as stream:
            stream.write(data)
        return path

    def test_arbitrary_bytes_lossless_roundtrip(self):
        raw = b"first\r\ntrailing whitespace \t\r\n\x00\xff\xfe" + bytes(range(256))
        original = self.fixture("arbitrary.bin", raw)
        self.assertEqual(seal.proof_bytes(original), raw)
        row = seal.capture(original, "synthetic", self.output)
        stored = self.output / row["stored_path"]
        self.assertEqual(original.read_bytes(), raw)
        self.assertEqual(gzip.decompress(stored.read_bytes()), raw)
        self.assertEqual(row["source_sha256"], hashlib.sha256(raw).hexdigest())
        self.assertEqual(row["source_bytes"], len(raw))
        self.assertEqual(row["stored_sha256"], hashlib.sha256(stored.read_bytes()).hexdigest())
        self.assertEqual(row["stored_bytes"], stored.stat().st_size)
        self.assertEqual(seal.digest(original), (row["source_sha256"], len(raw)))
        self.assertEqual(seal.digest(stored, decoded=True), (row["source_sha256"], len(raw)))
        self.assertEqual(seal.digest(stored), (row["stored_sha256"], row["stored_bytes"]))
        seal.inspected_snapshots_match([row])

    def test_inspected_old_captured_new_is_refused(self):
        original = self.fixture("mutable.bin", b"old inspected bytes\n")
        old = seal.proof_bytes(original)
        replacement = b"new captured bytes!\n"
        self.assertEqual(len(old), len(replacement))
        original.write_bytes(replacement)
        row = seal.capture(original, "synthetic", self.output)
        self.assertEqual(gzip.decompress((self.output / row["stored_path"]).read_bytes()), replacement)
        self.assertNotEqual(row["source_sha256"], hashlib.sha256(old).hexdigest())
        with self.assertRaisesRegex(RuntimeError, "captured bytes differ from inspected snapshot"):
            seal.inspected_snapshots_match([row])
        self.assertEqual(original.read_bytes(), replacement)

    def test_symlink_input_is_refused(self):
        target = self.fixture("real.bin", b"fixture-only target\n")
        link = self.case / "link.bin"
        link.symlink_to(target)
        for name, call in [
            ("proof_bytes", lambda: seal.proof_bytes(link)),
            ("capture", lambda: seal.capture(link, "synthetic", self.output)),
            ("digest", lambda: seal.digest(link)),
        ]:
            with self.subTest(helper=name):
                with self.assertRaisesRegex(RuntimeError, "noncanonical"):
                    call()
        self.assertEqual(target.read_bytes(), b"fixture-only target\n")
        self.assertTrue(link.is_symlink())
        self.assertFalse((self.output / "synthetic" / "link.bin.gz").exists())

    def test_existing_capture_is_not_overwritten(self):
        original = self.fixture("original.bin", b"original fixture\r\n")
        row = seal.capture(original, "synthetic", self.output)
        stored = self.output / row["stored_path"]
        compressed_before = stored.read_bytes()
        with self.assertRaises(FileExistsError):
            seal.capture(original, "synthetic", self.output)
        self.assertEqual(stored.read_bytes(), compressed_before)
        self.assertEqual(original.read_bytes(), b"original fixture\r\n")

    def test_failed_or_absent_harness_summaries_are_refused(self):
        cases = [
            ("failed", b"test result: FAILED. 2 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out;\n",
             "failed harness"),
            ("nonzero", b"test result: ok. 2 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out;\n",
             "failed harness"),
            ("failed_zero", b"test result: FAILED. 2 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;\n",
             "failed harness"),
            ("absent", b"build completed without a Rust harness summary\n", "no Rust harness summaries"),
        ]
        for name, content, message in cases:
            with self.subTest(case=name):
                path = self.fixture(name + ".log", content)
                with self.assertRaisesRegex(RuntimeError, message):
                    seal.test_counts(path)

    def test_source_witness_identity_and_equality(self):
        valid = (seal.SOURCE + "\n" + seal.TREE + "\n").encode("ascii")
        before = self.fixture("valid-before.txt", valid)
        after = self.fixture("valid-after.txt", valid)
        self.assertEqual(seal.witness_pair(before, after), {"source": seal.SOURCE, "tree": seal.TREE})
        for name, content in [
            ("wrong-source", ("0" * 40 + "\n" + seal.TREE + "\n").encode("ascii")),
            ("wrong-tree", (seal.SOURCE + "\n" + "0" * 40 + "\n").encode("ascii")),
            ("extra-line", valid + b"unexpected\n"),
        ]:
            with self.subTest(case=name):
                left = self.fixture(name + "-before.txt", content)
                right = self.fixture(name + "-after.txt", content)
                with self.assertRaisesRegex(RuntimeError, "does not identify qualified source/tree"):
                    seal.witness_pair(left, right)
        mismatch = self.fixture("mismatched-after.txt", valid + b"\n")
        with self.assertRaisesRegex(RuntimeError, "source witnesses differ"):
            seal.witness_pair(before, mismatch)

    def test_step_sequence_requires_exact_order_and_zero_status(self):
        expected = ["audit", "fmt", "whitespace"]
        valid = self.fixture("valid-steps.tsv", b"audit\t0\nfmt\t0\nwhitespace\t0\n")
        self.assertEqual(seal.step_results(valid, expected), [
            {"step": name, "exit_code": 0} for name in expected
        ])
        cases = {
            "missing": b"audit\t0\nwhitespace\t0\n",
            "duplicate": b"audit\t0\nfmt\t0\nfmt\t0\nwhitespace\t0\n",
            "reordered": b"fmt\t0\naudit\t0\nwhitespace\t0\n",
            "nonzero": b"audit\t0\nfmt\t1\nwhitespace\t0\n",
            "extra-column": b"audit\t0\nfmt\t0\textra\nwhitespace\t0\n",
            "unknown-step": b"audit\t0\nother\t0\nwhitespace\t0\n",
        }
        for name, content in cases.items():
            with self.subTest(case=name):
                path = self.fixture(name + "-steps.tsv", content)
                with self.assertRaisesRegex(RuntimeError, "step sequence/status mismatch"):
                    seal.step_results(path, expected)

    def test_mixed_harness_counts_are_derived(self):
        content = (
            b"running 4 tests\n"
            b"test alpha ... ok\n"
            b"test fixture_live ... ignored, synthetic fixture only\n"
            b"\x1b[32mtest result: ok. 3 passed; 0 failed; 1 ignored; 0 measured; 2 filtered out; finished in 0.01s\x1b[0m\n"
            b"another harness\n"
            b"test result: ok. 7 passed; 0 failed; 0 ignored; 1 measured; 0 filtered out; finished in 0.02s\n"
        )
        path = self.fixture("mixed.log", content)
        self.assertEqual(seal.test_counts(path), {
            "harnesses": 2, "passed": 10, "failed": 0, "ignored": 1,
            "measured": 1, "filtered_out": 2,
            "ignored_test_lines": ["test fixture_live ... ignored, synthetic fixture only"],
        })

    def test_inspected_file_missing_from_capture_is_refused(self):
        original = self.fixture("uncaptured.bin", b"inspected but not captured\n")
        seal.proof_bytes(original)
        with self.assertRaisesRegex(RuntimeError, "captured bytes differ from inspected snapshot"):
            seal.inspected_snapshots_match([])
        self.assertEqual(original.read_bytes(), b"inspected but not captured\n")


if __name__ == "__main__":
    unittest.main(verbosity=2)
