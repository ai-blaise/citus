#!/usr/bin/env python3
"""Lossless custody seal for the frozen Rustls repair; no CI/release promotion.

Run only after both bounded qualifications terminate, with exclusive ownership
of the proof directories during capture. Originals and interrupted captures are
never removed or overwritten. Counts describe Rust harness executions.
"""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

BASE = "e6efe2aed9a7e413f00e60faadf6dfe0c381ad6e"
BASE_TREE = "3534bb867093a2b7b5aba293649a1ad6a0711ef9"
SOURCE = "d10eeb6f4929a6779146bf6a022106f28c9350cc"
TREE = "3299d66142e6a5a93a2876d825a8ada07966d425"
REPO = Path("/home/spencer/citus-rustls-repair-sep30")
RUN = Path("/home/spencer/citus-rustls-repair-sep30-run")
CI = Path("/home/spencer/citus-current-ci-sep29/heads") / BASE
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
RESULT = re.compile(
    r"^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
    r"(\d+) ignored; (\d+) measured; (\d+) filtered out;", re.M
)
PROOF_BYTES = {}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args])


def signature(value):
    return tuple(getattr(value, field) for field in [
        "st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns"
    ])


def digest(path, decoded=False):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path,
            "noncanonical digest path")
    h = hashlib.sha256()
    size = 0
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), "rb") as raw:
        before = os.fstat(raw.fileno())
        require(stat.S_ISREG(before.st_mode), "digest input is not regular")
        stream = gzip.GzipFile(fileobj=raw, mode="rb") if decoded else raw
        try:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                h.update(chunk)
                size += len(chunk)
        finally:
            if decoded:
                stream.close()
        require(signature(before) == signature(os.fstat(raw.fileno())),
                "digest input changed")
    require(path.resolve(strict=True) == path and
            signature(before) == signature(os.stat(path, follow_symlinks=False)),
            "digest path changed")
    return h.hexdigest(), size


def replace_once(data, old, new):
    require(data.count(old) == 1, "source contract is not unique")
    return data.replace(old, new, 1)


def verify_source():
    require(git("rev-parse", "HEAD").decode().strip() == SOURCE, "HEAD drift")
    require(git("rev-parse", "HEAD^{tree}").decode().strip() == TREE, "tree drift")
    require(not git("diff", "--name-only"), "tracked working-tree drift")
    require(not git("diff", "--cached", "--name-only"), "index drift")
    changed = set(git("diff", "--name-only", BASE, SOURCE).decode().splitlines())
    require(changed == {
        "Cargo.lock", "operator/Cargo.toml", "docs/ai-blaise/NEW_FEATURES.md"
    }, "unexpected source delta")
    replacements = {
        "operator/Cargo.toml": [(
            b'version = "0.23", default-features = false, features = ["ring", "std"]',
            b'version = "0.23.45", default-features = false, features = ["ring", "std"]'
        )],
        "docs/ai-blaise/NEW_FEATURES.md": [(
            b'The separate distributed-trigger prerequisite is unchanged. Any future migration',
            b'The separate distributed-trigger prerequisite is unchanged. Any migration'
        )],
        "Cargo.lock": [
            (b'name = "rustls"\nversion = "0.23.40"',
             b'name = "rustls"\nversion = "0.23.45"'),
            (b'ef86cd5876211988985292b91c96a8f2d298df24e75989a43a3c73f2d4d8168b',
             b'0d41d731c7d2f962d1ccc364cec258de3c0e93b38c2fb3ba97ac74513048d634'),
            (b'name = "rustls-webpki"\nversion = "0.103.13"',
             b'name = "rustls-webpki"\nversion = "0.103.15"'),
            (b'61c429a8649f110dddef65e2a5ad240f747e85f7758a6bccc7e5777bd33f756e',
             b'f3c3cf1d8b1e7d4927e2d154c3fcb02979afb9939629c62cd9048d4f07b60ac2'),
        ],
    }
    for path, substitutions in replacements.items():
        expected = git("show", BASE + ":" + path)
        for old, new in substitutions:
            expected = replace_once(expected, old, new)
        require(git("show", SOURCE + ":" + path) == expected,
                "unexpected bytes: " + path)
    return {
        path: hashlib.sha256(git("show", SOURCE + ":" + path)).hexdigest()
        for path in [
            ".cargo/audit.toml", "ci/ai-blaise/cargo-audit-policy-smoke.sh",
            "ci/ai-blaise/v2-closure-check.sh", "rust-toolchain.toml"
        ]
    }


def checked_source(path):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path,
            "noncanonical/symlink source")
    require(any(root in path.parents for root in [RUN, CI]),
            "source outside explicit proof roots")
    require(stat.S_ISREG(path.stat().st_mode), "source is not a regular file")
    return path


def proof_bytes(path):
    path = checked_source(path)
    if path not in PROOF_BYTES:
        with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), "rb") as stream:
            before = os.fstat(stream.fileno())
            require(stat.S_ISREG(before.st_mode), "inspected input is not regular")
            data = stream.read()
            require(signature(before) == signature(os.fstat(stream.fileno())),
                    "inspected input changed")
        require(checked_source(path) == path and
                signature(before) == signature(os.stat(path, follow_symlinks=False)),
                "inspected path changed")
        PROOF_BYTES[path] = data
    return PROOF_BYTES[path]


def inspected_snapshots_match(rows):
    captured = {
        Path(row["source_path"]): (row["source_sha256"], row["source_bytes"])
        for row in rows
    }
    for path, data in PROOF_BYTES.items():
        require(captured.get(path) == (hashlib.sha256(data).hexdigest(), len(data)),
                "captured bytes differ from inspected snapshot: " + str(path))


def witness_pair(before, after):
    first, last = proof_bytes(before), proof_bytes(after)
    require(first == last, "source witnesses differ")
    require(first.decode("ascii").splitlines() == [SOURCE, TREE],
            "source witness does not identify qualified source/tree")
    return {"source": SOURCE, "tree": TREE}


def step_results(path, expected):
    rows = [
        line.split("\t") for line in proof_bytes(path).decode("ascii").splitlines()
    ]
    require(rows == [[name, "0"] for name in expected],
            "step sequence/status mismatch: " + str(path))
    return [{"step": row[0], "exit_code": int(row[1])} for row in rows]


def test_counts(path):
    text = ANSI.sub("", proof_bytes(path).decode("utf-8", errors="replace"))
    rows = RESULT.findall(text)
    require(rows, "no Rust harness summaries in " + str(path))
    require(all(row[0] == "ok" and int(row[2]) == 0 for row in rows),
            "failed harness in " + str(path))
    return {
        "harnesses": len(rows),
        "passed": sum(int(row[1]) for row in rows),
        "failed": sum(int(row[2]) for row in rows),
        "ignored": sum(int(row[3]) for row in rows),
        "measured": sum(int(row[4]) for row in rows),
        "filtered_out": sum(int(row[5]) for row in rows),
        "ignored_test_lines": [
            line for line in text.splitlines()
            if re.match(r"^test .+ \.\.\. ignored(?:$|,)", line)
        ],
    }


def capture(source, phase, output):
    source = checked_source(source)
    require(re.fullmatch(r"[A-Za-z0-9_.-]+", source.name) is not None,
            "unsafe source name")
    relative = Path(phase) / (source.name + ".gz")
    target = output / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with os.fdopen(os.open(source, os.O_RDONLY | os.O_NOFOLLOW), "rb") as incoming, \
            open(target, "xb") as outgoing:
        before = os.fstat(incoming.fileno())
        require(stat.S_ISREG(before.st_mode), "capture input is not regular")
        h = hashlib.sha256()
        size = 0
        with gzip.GzipFile(filename="", mode="wb", fileobj=outgoing, mtime=0) as zipped:
            for chunk in iter(lambda: incoming.read(1024 * 1024), b""):
                h.update(chunk)
                size += len(chunk)
                zipped.write(chunk)
        require(signature(before) == signature(os.fstat(incoming.fileno())),
                "source changed during capture")
    require(checked_source(source) == source and
            signature(before) == signature(os.stat(source, follow_symlinks=False)),
            "source path changed during capture")
    original = (h.hexdigest(), size)
    require(digest(source) == original and digest(target, decoded=True) == original,
            "lossless verification failed")
    stored_hash, stored_size = digest(target)
    return {
        "phase": phase, "source_path": str(source),
        "stored_path": relative.as_posix(),
        "source_sha256": original[0], "source_bytes": original[1],
        "stored_sha256": stored_hash, "stored_bytes": stored_size,
        "encoding": "gzip",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--supplemental-tests", required=True)
    parser.add_argument("--supplemental-clippy", required=True)
    parser.add_argument("--supplemental-exit", required=True)
    parser.add_argument("--supplemental-file", action="append", default=[])
    parser.add_argument("--extra-proof-file", action="append", default=[])
    parser.add_argument("--suffix", default="")
    args = parser.parse_args()
    os.umask(0o077)
    require(re.fullmatch(r"(?:-[A-Za-z0-9-]+)?", args.suffix) is not None,
            "invalid destination suffix")
    require(not git("status", "--porcelain"), "checkout must be clean before sealing")
    policy_hashes = verify_source()
    proof_bytes(Path(__file__).absolute())
    for raw, name in [
        (args.supplemental_tests, "additional-consumer-tests.log"),
        (args.supplemental_clippy, "additional-consumer-clippy.log"),
        (args.supplemental_exit, "supplement.exit"),
    ]:
        require(checked_source(raw) == RUN / name, "unexpected supplemental proof path")
    require(proof_bytes(RUN / "qualification.exit").decode("ascii").strip() == "0",
            "main qualification not successful")
    require(proof_bytes(args.supplemental_exit).decode("ascii").strip() == "0",
            "supplemental qualification not successful")
    witnesses = {
        "initial": witness_pair(RUN / "source-before.txt", RUN / "source-after.txt"),
        "supplemental": witness_pair(
            RUN / "supplement-source-before.txt", RUN / "supplement-source-after.txt"
        ),
    }
    steps = {
        "initial": step_results(RUN / "steps.tsv", [
            "audit", "dependency-tree", "fmt", "workspace-check",
            "consumer-tests", "consumer-clippy", "v2-closure", "whitespace"
        ]),
        "supplemental": step_results(RUN / "supplement-steps.tsv", [
            "additional-consumer-tests", "additional-consumer-clippy"
        ]),
    }
    for name, expected in {
        "baseline.sh": "e71d5eacc66a059e205e495bd7bcefcb5db98fcbc942f1ab93b8eb83fa0d027a",
        "qualification.sh": "207d554987ec5d019401def061363e4de9e3325361579e5043c755c1d5488254",
        "qualification.log": "5d00566ae2f5d058cd1da7fb58c7a034785d15ff568212fdca421f02fb4f65f8",
        "supplement.sh": "95a1805e63c6ab8a89f03a29de45d29a68a24fddc63102412d303b4f191f49c4",
    }.items():
        require(hashlib.sha256(proof_bytes(RUN / name)).hexdigest() == expected,
                "known proof hash differs: " + name)
    baseline = proof_bytes(RUN / "baseline.log").decode("utf-8")
    for marker in ["AUDIT_EXIT=1", "V2_EXIT=1", "BASELINE_EXPECTED_FAILURES_VERIFIED=1"]:
        require(baseline.splitlines().count(marker) == 1,
                "baseline literal verdict missing or duplicated: " + marker)
    require(baseline.count(BASE) == 2 and baseline.count(BASE_TREE) == 2,
            "baseline source/tree witnesses do not identify original source twice")
    require(b"RUSTSEC-2026-0285" in proof_bytes(RUN / "audit-red.log"),
            "missing original audit finding")
    require(b"Stale V2 closure wording remains in docs." in proof_bytes(RUN / "v2-red.log"),
            "missing original wording failure")
    require(b"cargo-audit-policy-smoke ok" in proof_bytes(RUN / "audit.log"),
            "audit policy smoke did not finish")
    counts = {
        "initial": test_counts(RUN / "consumer-tests.log"),
        "supplemental": test_counts(args.supplemental_tests),
    }
    counts["combined"] = {
        key: counts["initial"][key] + counts["supplemental"][key]
        for key in ["harnesses", "passed", "failed", "ignored", "measured", "filtered_out"]
    }
    selected = []
    for name in ["baseline.sh", "baseline.log", "audit-red.log", "v2-red.log"]:
        selected.append((RUN / name, "baseline"))
    for name in [
        "qualification.sh", "qualification.log", "qualification.exit", "steps.tsv",
        "source-before.txt", "source-after.txt", "audit.log", "dependency-tree.log",
        "fmt.log", "workspace-check.log", "consumer-tests.log", "consumer-clippy.log",
        "v2-closure.log", "whitespace.log", "lock-update.log"
    ]:
        selected.append((RUN / name, "qualification"))
    for raw in [
        args.supplemental_tests, args.supplemental_clippy, args.supplemental_exit,
        *args.supplemental_file
    ]:
        selected.append((checked_source(raw), "supplemental"))
    for name in [
        "supplement.sh", "supplement.log", "supplement-steps.tsv",
        "supplement-source-before.txt", "supplement-source-after.txt"
    ]:
        selected.append((RUN / name, "supplemental"))
    selected.append((checked_source(Path(__file__).absolute()), "control"))
    selected.extend((checked_source(raw), "control") for raw in args.extra_proof_file)
    for run, job in [
        (36646192338, 109669613189), (36646192219, 109669612773),
        (36646192341, 109669613296), (36646192248, 109669613133)
    ]:
        selected.append((
            CI / "logs" / ("run-%s-attempt-1" % run) / ("job-%s.log" % job),
            "hosted-predecessor"
        ))
        selected.append((
            CI / "snapshots/20260929T234514.115859Z" /
            ("run-%s-attempt-1-jobs-page-1.json" % run),
            "hosted-predecessor"
        ))
    keys = [(phase, path.name) for path, phase in selected]
    require(len(keys) == len(set(keys)), "duplicate archive destination")
    require(len(selected) == len({path for path, phase in selected}),
            "duplicate original proof source")
    for path, phase in selected:
        checked_source(path)
    output = REPO / "docs/ai-blaise/receipts" / (
        "2026-09-30-rustls-audit-evidence" + args.suffix
    )
    require(not output.exists(), "refusing to overwrite evidence")
    output.mkdir()
    rows = [capture(path, phase, output) for path, phase in selected]
    inspected_snapshots_match(rows)
    verify_source()
    for row in rows:
        require(digest(row["source_path"]) == (row["source_sha256"], row["source_bytes"]),
                "original changed after capture")
        require(digest(output / row["stored_path"], decoded=True) ==
                (row["source_sha256"], row["source_bytes"]), "decoded archive changed")
        require(digest(output / row["stored_path"]) ==
                (row["stored_sha256"], row["stored_bytes"]), "stored archive changed")
    verify_source()
    manifest = {
        "schema": "ai-blaise-rustls-custody-v1",
        "baseline_source": BASE, "baseline_tree": BASE_TREE,
        "baseline_verdicts": {
            "audit_exit": 1, "v2_exit": 1, "expected_failures_verified": 1
        },
        "qualified_source": SOURCE, "qualified_tree": TREE,
        "acceptance_scope": (
            "bounded local dependency and docs qualification only; "
            "hosted CI and whole-fork readiness not established"
        ),
        "policy_hashes": policy_hashes, "source_witnesses": witnesses,
        "steps": steps, "test_counts": counts, "files": rows,
    }
    encoded = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    with open(output / "manifest.json", "xb") as stream:
        stream.write(encoded)
        stream.flush()
        os.fsync(stream.fileno())
    manifest_hash = hashlib.sha256(encoded).hexdigest()
    require(digest(output / "manifest.json") == (manifest_hash, len(encoded)),
            "manifest readback differs")
    print(json.dumps({
        "manifest": str(output / "manifest.json"), "manifest_sha256": manifest_hash,
        "files": len(rows), "steps": steps, "test_counts": counts
    }, sort_keys=True))


if __name__ == "__main__":
    main()
