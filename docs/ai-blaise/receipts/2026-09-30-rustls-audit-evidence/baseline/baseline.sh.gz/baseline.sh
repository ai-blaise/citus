#!/usr/bin/env bash
set -uo pipefail
export PATH=/home/spencer/.cargo/bin:/usr/local/bin:/usr/bin:/bin
export CARGO_TARGET_DIR=/home/spencer/citus-rustls-repair-sep30-run/target
export CARGO_BUILD_JOBS=12
export RUST_TEST_THREADS=8
cd /home/spencer/citus-rustls-repair-sep30
proof=/home/spencer/citus-rustls-repair-sep30-run
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'exit 129' HUP
date -u +%FT%TZ
git rev-parse HEAD HEAD^{tree}
git status --porcelain
test "$(git rev-parse HEAD)" = e6efe2aed9a7e413f00e60faadf6dfe0c381ad6e || exit 2
test -z "$(git status --porcelain)" || exit 2
cargo --version
cargo audit --version
bash ci/ai-blaise/cargo-audit-policy-smoke.sh >"$proof/audit-red.log" 2>&1
audit_rc=$?
printf 'AUDIT_EXIT=%s\n' "$audit_rc"
bash ci/ai-blaise/v2-closure-check.sh >"$proof/v2-red.log" 2>&1
v2_rc=$?
printf 'V2_EXIT=%s\n' "$v2_rc"
git rev-parse HEAD HEAD^{tree}
git status --porcelain
sha256sum "$proof/audit-red.log" "$proof/v2-red.log"
date -u +%FT%TZ
if test "$audit_rc" != 1 || ! rg -q RUSTSEC-2026-0285 "$proof/audit-red.log"; then
  printf 'BASELINE_APPARATUS_OR_UNEXPECTED_AUDIT\n'
  exit 2
fi
if test "$v2_rc" != 1 || ! rg -q 'Stale V2 closure wording remains' "$proof/v2-red.log" || ! rg -q 'Any future migration' "$proof/v2-red.log"; then
  printf 'BASELINE_APPARATUS_OR_UNEXPECTED_V2\n'
  exit 2
fi
test -z "$(git status --porcelain)" || exit 2
printf 'BASELINE_EXPECTED_FAILURES_VERIFIED=1\n'
