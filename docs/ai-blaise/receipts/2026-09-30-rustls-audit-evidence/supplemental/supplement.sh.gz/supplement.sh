#!/usr/bin/env bash
set -uo pipefail
export PATH=/home/spencer/.cargo/bin:/usr/pgsql-17/bin:/usr/local/bin:/usr/bin:/bin
export CARGO_TARGET_DIR=/home/spencer/citus-rustls-repair-sep30-run/target
export CARGO_BUILD_JOBS=12 RUST_TEST_THREADS=8
export PG_CONFIG=/usr/pgsql-17/bin/pg_config
cd /home/spencer/citus-rustls-repair-sep30
proof=/home/spencer/citus-rustls-repair-sep30-run
failed=0
finish() {
  actual=$?
  trap - EXIT
  git rev-parse HEAD 'HEAD^{tree}' >"$proof/supplement-source-after.txt"
  git status --porcelain >>"$proof/supplement-source-after.txt"
  cmp -s "$proof/supplement-source-before.txt" "$proof/supplement-source-after.txt" || actual=2
  cg=$(awk -F: '$1 == "0" {print $3}' /proc/self/cgroup)
  for field in cpu.max pids.max pids.peak pids.events memory.max memory.peak memory.events; do
    if test -r "/sys/fs/cgroup$cg/$field"; then printf '%s\n' "$field"; sed -n '1,10p' "/sys/fs/cgroup$cg/$field"; fi
  done
  date -u +finished=%FT%TZ
  printf 'SUPPLEMENT_EXIT=%s\n' "$actual"
  printf '%s\n' "$actual" >"$proof/supplement.exit"
  exit "$actual"
}
trap finish EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
trap 'exit 129' HUP
test "$(git rev-parse HEAD)" = d10eeb6f4929a6779146bf6a022106f28c9350cc || exit 2
test -z "$(git status --porcelain)" || exit 2
git rev-parse HEAD 'HEAD^{tree}' >"$proof/supplement-source-before.txt"
date -u +started=%FT%TZ
printf 'INVOCATION_ID=%s\n' "${INVOCATION_ID:-unset}"
sha256sum "$proof/supplement.sh"
cargo --version
cargo audit --version
run_step() {
  name=$1
  shift
  printf 'STEP=%s COMMAND=' "$name"; printf '%q ' "$@"; printf '\n'
  "$@" >"$proof/$name.log" 2>&1
  actual=$?
  printf '%s\t%s\n' "$name" "$actual" >>"$proof/supplement-steps.tsv"
  printf 'STEP_EXIT=%s:%s\n' "$name" "$actual"
  if test "$actual" != 0; then failed=1; fi
}
test ! -e "$proof/supplement-steps.tsv" || exit 2
run_step additional-consumer-tests cargo test --locked --all-targets -p ai_blaise_citus_e2e -p ai_blaise_citus_sidecar_edge_functions -p ai_blaise_citus_sidecar_realtime
run_step additional-consumer-clippy cargo clippy --locked --all-targets -p ai_blaise_citus_e2e -p ai_blaise_citus_sidecar_edge_functions -p ai_blaise_citus_sidecar_realtime -- -D warnings
sha256sum "$proof/"*.log
exit "$failed"
